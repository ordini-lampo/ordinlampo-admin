# ============================================================
# GUIDA COMPLETA SCRITTURA LIBRETTI STARGRID
# ============================================================
# Documento: GUIDA-SCRITTURA-LIBRETTI-STARGRID-241224-1800.md
# Data: 24 Dicembre 2025 ore 18:00
# Stato: MASTER - Documento unico di riferimento
# ============================================================
#
# QUESTO FILE UNISCE:
# - META-LIBRETTO-STARGRID-PLATINUM-241224-1400.md (580 righe)
# - TEMPLATE-STRUTTURA-LIBRETTO-5DOC-241224-1400.md (1067 righe)
#
# SCOPO: Un UNICO riferimento per scrivere tutti i 21 libretti
# ============================================================
#
# SOGLIE UFFICIALI:
# - SCORE MOD (Software): 96+ per lancio
# - SCORE DOC (Libretto): 93+ per approvazione
# - PLATINUM = DOC >= 93 AND MOD >= 96
# ============================================================
#
# RANGE RIGHE UFFICIALI:
# - A-INTRO: max 200 righe
# - B-ARCHITETTURA: 300-500 righe
# - C-IMPLEMENTAZIONE: 500-1000 righe
# - D-GUARDRAIL: 200-400 righe
# - E-CHECKLIST: 300-500 righe
# - TOTALE LIBRETTO: 1500-2600 righe (diviso in 5 file)
# ============================================================


---

# INDICE COMPLETO

```
+==============================================================+
|        GUIDA COMPLETA SCRITTURA LIBRETTI - INDICE            |
+==============================================================+
|                                                              |
|  PARTE A: FILOSOFIA E REGOLE (dal META-LIBRETTO)             |
|  ----------------------------------------------------------- |
|  SEZ 1: FILOSOFIA - 7 Regole d'Oro                           |
|  SEZ 2: SISTEMA OCTASTARS - 10 Categorie + Soglie            |
|  SEZ 3: DUAL SCORE - DOC (93+) e MOD (96+)                   |
|  SEZ 4: STRUTTURA 5 DOCUMENTI - Overview                     |
|  SEZ 5: SISTEMA CHECKPOINT - Zero bit persi                  |
|  SEZ 6: CHECKLIST - 51 CORE + 190 SENTINEL                   |
|  SEZ 7: 20 ERRORI FATALI - DO NOT assoluti                   |
|  SEZ 8: PRE-SUBMIT - 30 punti obbligatori                    |
|                                                              |
|  PARTE B: TEMPLATE PRATICI (dal TEMPLATE-STRUTTURA)          |
|  ----------------------------------------------------------- |
|  SEZ 9: TEMPLATE A - INTRO (max 200 righe)                   |
|  SEZ 10: TEMPLATE B - ARCHITETTURA (300-500 righe)           |
|  SEZ 11: TEMPLATE C - IMPLEMENTAZIONE (500-1000 righe)       |
|  SEZ 12: TEMPLATE D - GUARDRAIL (200-400 righe)              |
|  SEZ 13: TEMPLATE E - CHECKLIST (300-500 righe)              |
|                                                              |
|  APPENDICE: QUICK REFERENCE                                  |
|                                                              |
+==============================================================+
```


---

# ############################################################
# PARTE A: FILOSOFIA E REGOLE
# ############################################################


---

# ============================================================
# SEZIONE 1: FILOSOFIA - 7 REGOLE D'ORO
# ============================================================

## 1.1 Cos'e un Libretto?

```
DEFINIZIONE:
Un libretto e' un documento tecnico COMPLETO che contiene
TUTTO il necessario per implementare UN modulo del sistema.

CARATTERISTICHE:
- AUTOSUFFICIENTE: Non richiede altri documenti
- DETERMINISTICO: Stesse istruzioni = stesso risultato
- VERIFICABILE: Include checklist per validare
- ENTERPRISE-GRADE: Qualita' adatta a investitori e SOC2
```

## 1.2 Le 7 Regole d'Oro

```
+==============================================================+
|                    7 REGOLE D'ORO PLATINUM                   |
+==============================================================+
|                                                              |
|  1. MEGLIO O NIENTE                                          |
|     Qualita' PRIMA di velocita'. Mai compromessi.            |
|     Se sotto 93/96 -> NON SI PROCEDE.                        |
|                                                              |
|  2. AUDIT PRIMA, CODICE POI                                  |
|     Verificare stato DB PRIMA di scrivere codice.            |
|     Query audit obbligatorie in ogni sessione.               |
|                                                              |
|  3. SINGLE SOURCE OF TRUTH                                   |
|     Tutto nel libretto, niente fuori.                        |
|     Se non e' nel libretto, non esiste.                      |
|                                                              |
|  4. DOPPIA VALUTAZIONE SEMPRE                                |
|     DOC >= 93 AND MOD >= 96 per PLATINUM.                    |
|     Entrambi devono passare.                                 |
|                                                              |
|  5. DO NOT > DO                                              |
|     Piu' importante sapere cosa NON fare.                    |
|     20 errori fatali = 20 incubi evitati.                    |
|                                                              |
|  6. NON-DEV FIRST                                            |
|     Se un investitore non capisce, e' incompleto.            |
|     Sezione A-INTRO obbligatoria e comprensibile.            |
|                                                              |
|  7. CHECKPOINT OBBLIGATORIO                                  |
|     Ogni sezione ha checkpoint. Zero bit persi.              |
|     Se checkpoint FAIL -> sezione incompleta.                |
|                                                              |
+==============================================================+
```


---

# ============================================================
# SEZIONE 2: SISTEMA OCTASTARS - 10 CATEGORIE
# ============================================================

## 2.1 Le 10 Categorie (10% ciascuna)

| # | Categoria | Cosa Valuta | Peso |
|---|-----------|-------------|------|
| 1 | **Architettura** | Pattern, separazione moduli, design | 10% |
| 2 | **UX/UI** | Esperienza utente, mobile, accessibilita' | 10% |
| 3 | **Sicurezza** | Auth, RLS, WAF, encryption | 10% |
| 4 | **Performance** | Velocita', cache, cold start | 10% |
| 5 | **Scalabilita'** | Multi-tenant, stateless, pooling | 10% |
| 6 | **Integrazioni** | Stripe, WhatsApp, Telegram, API | 10% |
| 7 | **DevOps** | CI/CD, deploy, IaC | 10% |
| 8 | **Compliance** | GDPR, privacy, fatturazione | 10% |
| 9 | **Analytics** | Tracking, metriche, SLO | 10% |
| 10 | **Business** | Pricing, referral, unit economics | 10% |

## 2.2 Soglie Ufficiali PLATINUM

| Range | Livello | Icona | Significato |
|-------|---------|-------|-------------|
| **96-100** | **PLATINUM** | DIAMANTE | **TARGET - Enterprise bulletproof** |
| 93-95 | GOLD+ | ORO+ | Accettabile per DOC, non per MOD |
| 90-92 | GOLD | ORO | Buono ma non per lancio |
| 81-89 | SILVER | ARGENTO | Staging only |
| 70-80 | BRONZE | BRONZO | Development only |
| <70 | FAIL | X | Riscrivere |

## 2.3 Requisiti 96+ per Categoria

### ARCHITETTURA (96+ richiede)
- Moduli separati con confini chiari
- Pattern documentati (Outbox, State Machine)
- Dipendenze esplicite
- Migrazioni numerate con rollback
- Invarianti enforce da trigger

### SICUREZZA (96+ richiede)
- RLS su TUTTE le tabelle con dati utente
- SECURITY DEFINER + search_path su tutte le funzioni
- Rate limiting per IP/tenant/device
- Kill-switch funzionante
- No secrets in code

### PERFORMANCE (96+ richiede)
- Cold start < 1s
- Indici verificati con EXPLAIN ANALYZE
- Cache strategy documentata
- Bundle < 500KB gzipped

### AFFIDABILITA' (96+ richiede)
- Idempotency su operazioni critiche
- Retry con backoff esponenziale
- DLQ con reason_code
- Fallback provider configurato


---

# ============================================================
# SEZIONE 3: DUAL SCORE - DOC (93+) E MOD (96+)
# ============================================================

## 3.1 Filosofia Dual Score

```
+==============================================================+
|                                                              |
|  SCORE DOC = Qualita' LIBRETTO (documentazione)              |
|  Soglia minima: 93/100                                       |
|                                                              |
|  SCORE MOD = Qualita' MODULO (software)                      |
|  Soglia minima: 96/100 per lancio                            |
|                                                              |
|  PLATINUM = DOC >= 93 AND MOD >= 96                          |
|                                                              |
+==============================================================+
```

## 3.2 SCORE DOC - Valutazione Documentazione (10 x 10%)

| # | Categoria | Cosa Misura |
|---|-----------|-------------|
| 1 | Completezza | Tutte le sezioni? Nessun TODO? |
| 2 | Chiarezza | Non-dev capisce? |
| 3 | Struttura | 5 documenti rispettati? |
| 4 | Codice | Codice completo e funzionante? |
| 5 | Checkpoint | Tutti PASS? |
| 6 | DO/DO NOT | 10+ regole per tipo? |
| 7 | Checklist | 51 CHECK + 9+ SENTINEL? |
| 8 | Diagrammi | Flussi visivi chiari? |
| 9 | Manutenibilita' | Facile da aggiornare? |
| 10 | Audit-ready | Pronto per validazione? |

## 3.3 SCORE MOD - Valutazione Software (10 x 10%)

| # | Categoria | Cosa Misura |
|---|-----------|-------------|
| 1 | Architettura | Design pattern corretti? |
| 2 | Sicurezza | RLS? Auth? Validation? |
| 3 | Performance | Query ottimizzate? |
| 4 | Scalabilita' | Multi-tenant? Stateless? |
| 5 | Affidabilita' | Idempotenza? DLQ? |
| 6 | Osservabilita' | Log? Metriche? Alert? |
| 7 | Manutenibilita' | Codice pulito? |
| 8 | Integrazioni | API chiare? |
| 9 | Compliance | GDPR? Audit trail? |
| 10 | Recovery | Backup? Rollback? |

## 3.4 PAGELLA MODULO PLATINUM

```
+==============================================================+
|                PAGELLA MODULO: [COD] - [NOME]                |
+==============================================================+
|                                                              |
|  SCORE DOC: __/100  (Soglia: 93+)  [PASS/FAIL]              |
|  SCORE MOD: __/100  (Soglia: 96+)  [PASS/FAIL]              |
|                                                              |
|  PLATINUM: DOC >= 93 AND MOD >= 96 = [YES/NO]               |
|                                                              |
+==============================================================+
```

## 3.5 Regole Verdetto

```
PLATINUM (LANCIO OK):
   DOC >= 93 AND MOD >= 96

GOLD (QUASI PRONTO):
   DOC >= 93 AND MOD 90-95
   -> Fix P1 entro 1 settimana

SILVER (STAGING ONLY):
   DOC >= 81 AND MOD 81-89
   -> Fix P0+P1 prima di produzione

NO-GO:
   DOC < 81 OR MOD < 81
   -> Riscrivere

STOP ASSOLUTO:
   DOC < 70 -> Riscrivere libretto
   MOD < 70 -> Riscrivere modulo
```


---

# === CHECKPOINT PARTE 1 (SEZ 1-3) ===

## Verifica Contenuti da META-LIBRETTO

| Elemento | Fonte (righe) | Presente | Status |
|----------|---------------|----------|--------|
| Definizione libretto | META 46-58 | SI | OK |
| 7 Regole d'Oro | META 62-96 | SI | OK |
| 10 Categorie OCTASTARS | META 107-118 | SI | OK |
| Soglie PLATINUM | META 122-129 | SI | OK |
| Requisiti 96+ (4 categorie) | META 133-157 | SI | OK |
| Dual Score filosofia | META 168-180 | SI | OK |
| SCORE DOC (10 criteri) | META 184-195 | SI | OK |
| SCORE MOD (10 criteri) | META 199-210 | SI | OK |
| Pagella template | META 214-225 | SI | OK |
| Regole verdetto | META 229-248 | SI | OK |

## Conteggio

| Metrica | Valore |
|---------|--------|
| Righe scritte | ~220 |
| Tabelle | 6 |
| Code block | 5 |

## Integrita'

- [x] Nessun [TODO]
- [x] Nessun [DA COMPLETARE]
- [x] Code block chiusi
- [x] Tabelle complete

**CHECKPOINT PARTE 1: PASS**

---


# ============================================================
# SEZIONE 4: STRUTTURA 5 DOCUMENTI
# ============================================================

## 4.1 Overview

```
LIBRETTO-[COD]/
|
+-- A-INTRO-[COD].md              -> Investitori (max 200 righe)
+-- B-ARCHITETTURA-[COD].md       -> Schema DB (300-500 righe)
+-- C-IMPLEMENTAZIONE-[COD].md    -> Codice (500-1000 righe)
+-- D-GUARDRAIL-[COD].md          -> Sicurezza (200-400 righe)
+-- E-CHECKLIST-[COD].md          -> Audit (300-500 righe)

TOTALE: 1500-2600 righe per libretto (5 file gestibili)
```

## 4.2 Dettaglio Sezioni

| Sez | Nome | Righe | Scopo | Audience |
|-----|------|-------|-------|----------|
| A | INTRO | ~200 | Panoramica | Investitori |
| B | ARCHITETTURA | 300-500 | Schema DB | Dev senior |
| C | IMPLEMENTAZIONE | 500-1000 | Codice | Dev |
| D | GUARDRAIL | 200-400 | Sicurezza | Tutti |
| E | CHECKLIST | 300-500 | Audit | QA |

## 4.3 Contenuto Obbligatorio per Sezione

### A-INTRO
- Header metadata
- Tabella funzioni
- Descrizione non-dev
- Dipendenze
- CHECKPOINT-A

### B-ARCHITETTURA
- Schema SQL completo
- Diagrammi relazioni
- Invarianti
- State machine
- CHECKPOINT-B

### C-IMPLEMENTAZIONE
- Migrazioni numerate
- Funzioni PostgreSQL (SECURITY DEFINER)
- Workers Netlify/Railway (stack)
- Type definitions
- CHECKPOINT-C

### D-GUARDRAIL
- Matrice RLS
- Rate limiting
- DO NOT (minimo 10)
- DO (minimo 10)
- CHECKPOINT-D

### E-CHECKLIST
- 51 CHECK CORE
- 9+ SENTINEL
- PAGELLA DOC + MOD
- Errori/Azioni/Migliorie
- CHECKPOINT-E


---

# ============================================================
# SEZIONE 5: SISTEMA CHECKPOINT
# ============================================================

## 5.1 Scopo

```
PROBLEMA: Documenti lunghi, context window AI limitata
SOLUZIONE: Checkpoint alla fine di OGNI sezione
RISULTATO: ZERO BIT PERSI
```

## 5.2 Template Checkpoint

```markdown
---

# === CHECKPOINT-[X] ===

## Verifica Completezza

| Elemento | Atteso | Presente | Status |
|----------|--------|----------|--------|
| [Elemento] | N | _ | [OK/FAIL] |

## Conteggio

| Tipo | Conteggio |
|------|-----------|
| Righe | __ |
| Tabelle | __ |
| Code block | __ |

## Integrita'

- [ ] Nessun [TODO]
- [ ] Nessun [DA COMPLETARE]
- [ ] Code block chiusi
- [ ] Tabelle complete

## Firma

| Campo | Valore |
|-------|--------|
| Sezione | [X] |
| Data | [GGMMAA-HHMM] |
| Status | COMPLETO/PARZIALE/INCOMPLETO |

---
```

## 5.3 Quando Usare i Checkpoint

| Situazione | Azione |
|------------|--------|
| Fine sezione A-INTRO | CHECKPOINT-A obbligatorio |
| Fine sezione B-ARCHITETTURA | CHECKPOINT-B obbligatorio |
| Fine sezione C-IMPLEMENTAZIONE | CHECKPOINT-C obbligatorio |
| Fine sezione D-GUARDRAIL | CHECKPOINT-D obbligatorio |
| Fine sezione E-CHECKLIST | CHECKPOINT-E obbligatorio |
| Documento > 500 righe | Checkpoint intermedio |
| Cambio sessione AI | Checkpoint prima di chiudere |


---

# ============================================================
# SEZIONE 6: CHECKLIST - 51 CORE + 190 SENTINEL
# ============================================================

## 6.1 Riepilogo Numerico

| Tipo | Quantita' |
|------|-----------|
| CHECK CORE | 51 |
| SENTINEL (20 moduli x 9) | 180 |
| SENTINEL GRD (eccezione) | 10 |
| **TOTALE** | **241** |

## 6.2 I 51 CHECK CORE (Dettaglio per Categoria)

### PKG - Pacchetto (6 check)

| ID | Check | Cosa Verifica |
|----|-------|---------------|
| PKG-01 | Package.json presente | File configurazione esiste |
| PKG-02 | Dipendenze bloccate | Versioni fisse, no ^ o ~ |
| PKG-03 | Script build funziona | npm run build OK |
| PKG-04 | Script test funziona | npm run test OK |
| PKG-05 | No dipendenze vulnerabili | npm audit clean |
| PKG-06 | TypeScript strict | tsconfig strict: true |

### ENV - Ambienti (5 check)

| ID | Check | Cosa Verifica |
|----|-------|---------------|
| ENV-01 | .env.example presente | Template variabili |
| ENV-02 | Staging configurato | Ambiente test |
| ENV-03 | Production configurato | Ambiente live |
| ENV-04 | Secrets in vault | No secrets in code |
| ENV-05 | Variabili documentate | Ogni var ha descrizione |

### DB - Database (10 check)

| ID | Check | Cosa Verifica |
|----|-------|---------------|
| DB-01 | Schema app esiste | Namespace isolato |
| DB-02 | Migrazioni numerate | 001_, 002_, ... |
| DB-03 | Rollback presenti | Per ogni migrazione |
| DB-04 | RLS attivo | Su tabelle utente |
| DB-05 | Indici verificati | EXPLAIN ANALYZE OK |
| DB-06 | FK con ON DELETE | Cascade/Restrict definito |
| DB-07 | Trigger updated_at | Automatico su UPDATE |
| DB-08 | COMMENT su tabelle | Documentazione DB |
| DB-09 | No query N+1 | Join ottimizzati |
| DB-10 | Connection pooling | Hyperdrive configurato |

### SEC - Sicurezza (8 check)

| ID | Check | Cosa Verifica |
|----|-------|---------------|
| SEC-01 | SECURITY DEFINER | Su tutte le funzioni |
| SEC-02 | search_path | app, pg_temp |
| SEC-03 | Input validation | Zod su ogni endpoint |
| SEC-04 | Rate limiting | Configurato e testato |
| SEC-05 | No PII in log | Verificato |
| SEC-06 | JWT validation | Ordini-Lampo Auth (custom session-cookie) middleware |
| SEC-07 | CORS configurato | Origins whitelist |
| SEC-08 | Kill-switch | Funzionante |

### RUN - Runtime (5 check)

| ID | Check | Cosa Verifica |
|----|-------|---------------|
| RUN-01 | Cold start < 1s | Misurato |
| RUN-02 | Memory < 128MB | Worker limits |
| RUN-03 | Timeout gestito | Graceful shutdown |
| RUN-04 | Error handling | Try/catch globale |
| RUN-05 | Health endpoint | /health risponde |

### OBS - Osservabilita' (4 check)

| ID | Check | Cosa Verifica |
|----|-------|---------------|
| OBS-01 | Logging strutturato | JSON format |
| OBS-02 | Correlation ID | Request tracing |
| OBS-03 | Metriche esposte | Prometheus format |
| OBS-04 | Alert configurati | PagerDuty/Slack |

### DATA - Integrita' Dati (4 check)

| ID | Check | Cosa Verifica |
|----|-------|---------------|
| DATA-01 | Idempotency key | Su write operations |
| DATA-02 | Transazioni ACID | BEGIN/COMMIT |
| DATA-03 | Constraint CHECK | Validazione DB |
| DATA-04 | Soft delete | status invece di DELETE |

### REC - Recovery (3 check)

| ID | Check | Cosa Verifica |
|----|-------|---------------|
| REC-01 | Backup automatico | Schedule configurato |
| REC-02 | PITR disponibile | Point-in-time recovery |
| REC-03 | Restore testato | Drill eseguito |

### LIVE - Go-Live (4 check)

| ID | Check | Cosa Verifica |
|----|-------|---------------|
| LIVE-01 | Smoke test staging | Passato |
| LIVE-02 | Load test | Capacita' verificata |
| LIVE-03 | Rollback plan | Documentato |
| LIVE-04 | Runbook presente | Procedure operative |

### OPS - Operazioni (2 check)

| ID | Check | Cosa Verifica |
|----|-------|---------------|
| OPS-01 | Documentazione | README aggiornato |
| OPS-02 | Contatti emergenza | Lista disponibile |

**TOTALE: 51 CHECK CORE**

## 6.3 I 190 SENTINEL (per modulo)

| Modulo | Sentinel | Note |
|--------|----------|------|
| 20 moduli standard | 9 ciascuno | 180 totali |
| GRD (Guardian) | 10 | +GRD-10 Order Resilience |
| **TOTALE** | **190** | |

### Struttura SENTINEL per modulo (9 standard)

| ID | Nome Sentinel | Cosa Verifica |
|----|---------------|---------------|
| [COD]-01 | Core Function | Funzione principale OK |
| [COD]-02 | Dependencies | Dipendenze rispettate |
| [COD]-03 | Data Integrity | Dati consistenti |
| [COD]-04 | Security | RLS/Auth specifico |
| [COD]-05 | Performance | Latency target |
| [COD]-06 | Error Handling | Errori gestiti |
| [COD]-07 | Integration | API esterne OK |
| [COD]-08 | Audit Trail | Logging completo |
| [COD]-09 | Recovery | Ripristino possibile |

## 6.4 Formula Score

```
STANDARD (51 CORE + 9 SENTINEL = 60):
Score = (PASS + PARZIALE x 0.5) / (60 - N/A) x 100

GRD (51 CORE + 10 SENTINEL = 61):
Score = (PASS + PARZIALE x 0.5) / (61 - N/A) x 100

ESEMPIO:
PASS:     45
PARZIALE: 6 (x 0.5 = 3)
N/A:      5
VALIDI:   60 - 5 = 55

Score = (45 + 3) / 55 x 100 = 87.3/100
```


---

# === CHECKPOINT PARTE 2 (SEZ 4-6) ===

## Verifica Contenuti da META-LIBRETTO

| Elemento | Fonte (righe) | Presente | Status |
|----------|---------------|----------|--------|
| Struttura 5 doc overview | META 259-269 | SI | OK |
| Dettaglio sezioni tabella | META 273-279 | SI | OK |
| Contenuto obbligatorio A-E | META 283-316 | SI | OK |
| Sistema checkpoint scopo | META 327-331 | SI | OK |
| Template checkpoint | META 335-370 | SI | OK |
| Riepilogo numerico 51+190 | META 381-386 | SI | OK |
| 51 CHECK CORE categorie | META 390-402 | SI + DETTAGLIO | OK |
| 190 SENTINEL | META 406-410 | SI | OK |
| Formula score | META 414-420 | SI | OK |

## Conteggio

| Metrica | Valore |
|---------|--------|
| Righe aggiunte | ~280 |
| Tabelle | 15 |
| Code block | 3 |

## Integrita'

- [x] Nessun [TODO]
- [x] Nessun [DA COMPLETARE]
- [x] Code block chiusi
- [x] Tabelle complete
- [x] 51 CHECK CORE tutti dettagliati

**CHECKPOINT PARTE 2: PASS**

---


# ============================================================
# SEZIONE 7: 20 ERRORI FATALI (DO NOT)
# ============================================================

```
+==============================================================+
|                 20 ERRORI FATALI - DO NOT                    |
+==============================================================+
|                                                              |
|  DATABASE:                                                   |
|  1. MAI funzione senza SECURITY DEFINER                      |
|  2. MAI funzione senza search_path = app, pg_temp            |
|  3. MAI tabella utente senza RLS                             |
|  4. MAI UPDATE/DELETE su tabelle append-only                 |
|  5. MAI tabella senza indici lookup                          |
|                                                              |
|  SICUREZZA:                                                  |
|  6. MAI secrets hardcodati nel codice                        |
|  7. MAI credenziali DB esposte al frontend                   |
|  8. MAI PII nei log                                          |
|  9. MAI bypassare validazione input                          |
|  10. MAI disabilitare rate limiting                          |
|                                                              |
|  AFFIDABILITA':                                              |
|  11. MAI operazione critica senza idempotency_key            |
|  12. MAI retry infiniti senza backoff                        |
|  13. MAI perdere messaggi senza DLQ                          |
|  14. MAI ignorare errori silenziosamente                     |
|  15. MAI hash senza payload canonico                         |
|                                                              |
|  PROCESSO:                                                   |
|  16. MAI deploy senza staging test                           |
|  17. MAI prod senza backup testato                           |
|  18. MAI live senza kill-switch                              |
|  19. MAI libretto senza checklist                            |
|  20. MAI procedere con DOC < 93 o MOD < 96                   |
|                                                              |
+==============================================================+
```

## 7.1 Dettaglio Errori Database (1-5)

| # | Errore | Conseguenza | Prevenzione |
|---|--------|-------------|-------------|
| 1 | No SECURITY DEFINER | Privilege escalation | Template funzione standard |
| 2 | No search_path | SQL injection | Template con search_path |
| 3 | No RLS | Data leak cross-tenant | Checklist DB-04 |
| 4 | UPDATE su append-only | Audit trail corrotto | Trigger blocco |
| 5 | No indici | Query lente O(n) | EXPLAIN obbligatorio |

## 7.2 Dettaglio Errori Sicurezza (6-10)

| # | Errore | Conseguenza | Prevenzione |
|---|--------|-------------|-------------|
| 6 | Secrets in code | Leak su GitHub | Secret scanner CI |
| 7 | DB creds frontend | Accesso diretto DB | Solo API, mai direct |
| 8 | PII nei log | Violazione GDPR | Regex sanitizer |
| 9 | No input validation | Injection attacks | Zod obbligatorio |
| 10 | No rate limit | DDoS, abuse | Middleware default |

## 7.3 Dettaglio Errori Affidabilita' (11-15)

| # | Errore | Conseguenza | Prevenzione |
|---|--------|-------------|-------------|
| 11 | No idempotency | Ordini duplicati | Pattern standard |
| 12 | Retry infiniti | Loop, costi | Backoff esponenziale |
| 13 | No DLQ | Messaggi persi | Queue architecture |
| 14 | Silent errors | Bug nascosti | Error boundary |
| 15 | Hash non canonico | Collisioni | JSON.stringify sorted |

## 7.4 Dettaglio Errori Processo (16-20)

| # | Errore | Conseguenza | Prevenzione |
|---|--------|-------------|-------------|
| 16 | No staging | Bug in prod | Pipeline CI/CD |
| 17 | No backup test | Recovery fallisce | Drill mensile |
| 18 | No kill-switch | Impossibile fermare | GOV module |
| 19 | No checklist | Quality random | Template E obbligatorio |
| 20 | Score < soglia | Prodotto instabile | Gate automatico |


---

# ============================================================
# SEZIONE 8: PRE-SUBMIT - 30 PUNTI
# ============================================================

## 8.1 Checklist Pre-Submit (30 punti)

### A) STRUTTURA (6 punti)

| # | Check | Descrizione |
|---|-------|-------------|
| 1 | A-INTRO presente | File esiste e < 200 righe |
| 2 | B-ARCHITETTURA presente | File esiste |
| 3 | C-IMPLEMENTAZIONE presente | File esiste |
| 4 | D-GUARDRAIL presente | File esiste |
| 5 | E-CHECKLIST presente | File esiste |
| 6 | Naming corretto | LIBRETTO-[COD]-*.md |

### B) INTRO (4 punti)

| # | Check | Descrizione |
|---|-------|-------------|
| 7 | Tabella funzioni | Lista completa funzionalita' |
| 8 | Descrizione non-dev | Comprensibile a investitori |
| 9 | Dipendenze | Lista moduli richiesti |
| 10 | Strumenti valutazione | Query/endpoint health |

### C) TECNICO (8 punti)

| # | Check | Descrizione |
|---|-------|-------------|
| 11 | Schema SQL completo | CREATE TABLE, INDEX, etc |
| 12 | SECURITY DEFINER | Su tutte le funzioni |
| 13 | search_path | app, pg_temp |
| 14 | RLS attivo | ALTER TABLE ENABLE RLS |
| 15 | Invarianti documentate | Regole sempre vere |
| 16 | Migrazioni numerate | 001_, 002_, ... |
| 17 | Rollback documentato | Per ogni migrazione |
| 18 | Worker code presente | TypeScript completo |

### D) SICUREZZA (5 punti)

| # | Check | Descrizione |
|---|-------|-------------|
| 19 | DO NOT (minimo 10) | Lista azioni vietate |
| 20 | DO (minimo 10) | Lista best practice |
| 21 | Rate limiting | Configurazione presente |
| 22 | No secrets hardcodati | Verificato |
| 23 | Kill-switch | Procedura documentata |

### E) CHECKLIST (4 punti)

| # | Check | Descrizione |
|---|-------|-------------|
| 24 | 51 Check Core | Tutti compilati |
| 25 | 9+ Sentinel | Specifici modulo |
| 26 | PAGELLA presente | DOC + MOD score |
| 27 | Formula corretta | Calcolo verificabile |

### F) META (3 punti)

| # | Check | Descrizione |
|---|-------|-------------|
| 28 | Data aggiornata | Riflette stato attuale |
| 29 | CHECKPOINT in ogni sezione | A, B, C, D, E |
| 30 | Naming GGMMAA-HHMM | Timestamp nel nome |

## 8.2 Interpretazione Pre-Submit

| Punti | Verdetto | Azione |
|-------|----------|--------|
| **30/30** | PRONTO | Procedi con submit |
| 25-29 | QUASI | Fix minori, poi submit |
| 20-24 | INCOMPLETO | Completare sezioni mancanti |
| < 20 | INSUFFICIENTE | Riscrivere |

## 8.3 Ordine di Compilazione Consigliato

```
1. A-INTRO      -> Per chiarire scope
2. B-ARCHITETTURA -> Schema DB prima del codice
3. D-GUARDRAIL  -> Regole PRIMA di implementare
4. C-IMPLEMENTAZIONE -> Codice seguendo guardrail
5. E-CHECKLIST  -> Audit DOPO tutto il resto
```


---

# === CHECKPOINT PARTE 3 (SEZ 7-8) ===

## Verifica Contenuti da META-LIBRETTO

| Elemento | Fonte (righe) | Presente | Status |
|----------|---------------|----------|--------|
| 20 Errori Fatali (box) | META 429-463 | SI | OK |
| Errori Database (1-5) | META 434-439 | SI + DETTAGLIO | OK |
| Errori Sicurezza (6-10) | META 441-446 | SI + DETTAGLIO | OK |
| Errori Affidabilita' (11-15) | META 448-453 | SI + DETTAGLIO | OK |
| Errori Processo (16-20) | META 455-460 | SI + DETTAGLIO | OK |
| Pre-Submit 30 punti | META 472-514 | SI | OK |
| Struttura (6) | META 474-480 | SI | OK |
| Intro (4) | META 482-486 | SI | OK |
| Tecnico (8) | META 488-496 | SI | OK |
| Sicurezza (5) | META 498-503 | SI | OK |
| Checklist (4) | META 505-509 | SI | OK |
| Meta (3) | META 511-514 | SI | OK |
| Interpretazione | META 518-523 | SI | OK |

## Conteggio

| Metrica | Valore |
|---------|--------|
| Righe aggiunte | ~170 |
| Tabelle | 10 |
| Code block | 2 |

## Integrita'

- [x] Nessun [TODO]
- [x] Nessun [DA COMPLETARE]
- [x] Code block chiusi
- [x] Tabelle complete
- [x] 20 errori fatali tutti presenti
- [x] 30 punti pre-submit tutti presenti

**CHECKPOINT PARTE 3: PASS**

**FINE PARTE A (FILOSOFIA E REGOLE): COMPLETA**

---


# ############################################################
# PARTE B: TEMPLATE PRATICI
# ############################################################


---

# ============================================================
# SEZIONE 9: TEMPLATE A - INTRO (Max 200 righe)
# ============================================================
# Scopo: Panoramica per NON-DEV e investitori
# Tempo lettura: 5-10 minuti
# ============================================================

```markdown
# A-INTRO-[COD].md

# ============================================================
# LIBRETTO [NOME] ([COD]) - INTRODUZIONE
# ============================================================
# Versione: [X.X]
# Data: [DD/MM/YYYY]
# Stato: [DRAFT | REVIEW | FINAL]
# Stack: Railway API (server runtime) + Railway Postgres PostgreSQL + Ordini-Lampo Auth (custom session-cookie)
# ============================================================


---

# 1. HEADER

| Campo | Valore |
|-------|--------|
| Codice Modulo | [COD] |
| Nome Modulo | [NOME] |
| Versione | [X.X] |
| Ultima modifica | [DD/MM/YYYY] |
| Stato | [DRAFT/REVIEW/FINAL] |
| Dipende da | [L0, COR, ...] |
| Richiesto da | [MSG, VAU, ...] |


---

# 2. TABELLA RIEPILOGATIVA FUNZIONI

| # | Funzione | Descrizione | Priorita' |
|---|----------|-------------|-----------|
| 1 | [funzione_1] | [cosa fa in 10 parole] | P0 |
| 2 | [funzione_2] | [cosa fa in 10 parole] | P0 |
| 3 | [funzione_3] | [cosa fa in 10 parole] | P1 |
| ... | ... | ... | ... |

**Totale funzioni: [N]**


---

# 3. DESCRIZIONE NON-DEV (per chi non programma)

## Cosa fa questo modulo?

[Spiegazione in linguaggio semplice, 3-5 frasi.
Usare analogie quotidiane: "Come un...", "Immagina che..."]

## Esempio pratico

```
SCENARIO: [situazione reale]

1. [Passo 1 - cosa succede]
2. [Passo 2 - cosa fa il modulo]
3. [Passo 3 - risultato finale]
```

## Perche' e' importante?

- [Motivo business 1]
- [Motivo business 2]
- [Motivo business 3]


---

# 4. PANORAMICA INVESTITORI

## Value Proposition

[2-3 frasi su come questo modulo crea valore]

## Differenziazione Competitiva

| Competitor | Loro approccio | Nostro approccio |
|------------|----------------|------------------|
| [Nome] | [come fanno] | [come facciamo meglio] |

## Scalabilita'

| Metrica | Ora | 100 ristoranti | 1000 ristoranti |
|---------|-----|----------------|-----------------|
| [metrica] | [valore] | [valore] | [valore] |

## Risk Mitigation

| Rischio | Probabilita' | Mitigazione |
|---------|--------------|-------------|
| [rischio] | Bassa/Media/Alta | [come gestiamo] |


---

# 5. INDICE DOCUMENTI CORRELATI

## Documenti Libretto

| Doc | Nome | Scopo |
|-----|------|-------|
| A | A-INTRO-[COD].md | Questo documento |
| B | B-ARCHITETTURA-[COD].md | Schema DB, invarianti |
| C | C-IMPLEMENTAZIONE-[COD].md | Codice, istruzioni |
| D | D-GUARDRAIL-[COD].md | Sicurezza, DO NOT |
| E | E-CHECKLIST-[COD].md | Audit, esito reale |

## Libretti Dipendenti

| Codice | Nome | Relazione |
|--------|------|-----------|
| [COD] | [Nome] | [tipo relazione] |

## Documentazione Esterna

| Risorsa | Link | Scopo |
|---------|------|-------|
| [nome] | [url] | [perche' utile] |


---

# 6. STRUMENTI VALUTAZIONE RAPIDA

## Query SQL per verificare stato

```sql
-- Verifica [cosa]
SELECT ...;

-- Verifica [altra cosa]
SELECT ...;
```

## Endpoint Health Check

```bash
# Verifica API
curl -X GET https://api.ordini-lampo.it/health/[cod]

# Risposta attesa
{ "status": "ok", "module": "[COD]", "version": "[X.X]" }
```

## Dashboard Link

| Dashboard | URL | Cosa mostra |
|-----------|-----|-------------|
| [nome] | [url] | [descrizione] |


---

# === CHECKPOINT-A ===

## Verifica Completezza

| Elemento | Atteso | Presente | Status |
|----------|--------|----------|--------|
| Header | 7 campi | _ | [OK/FAIL] |
| Funzioni | N righe | _ | [OK/FAIL] |
| Descrizione non-dev | 3 sezioni | _ | [OK/FAIL] |
| Investitori | 4 sezioni | _ | [OK/FAIL] |
| Documenti correlati | 3 tabelle | _ | [OK/FAIL] |
| Strumenti | Query + endpoint | _ | [OK/FAIL] |

## Firma

| Campo | Valore |
|-------|--------|
| Sezione | A |
| Data | [GGMMAA-HHMM] |
| Status | COMPLETO/PARZIALE/INCOMPLETO |

---

# ============================================================
# FINE A-INTRO
# ============================================================
```


---

# ============================================================
# SEZIONE 10: TEMPLATE B - ARCHITETTURA (300-500 righe)
# ============================================================
# Scopo: Schema DB + Design tecnico
# Audience: Dev senior, AI reviewer
# ============================================================

```markdown
# B-ARCHITETTURA-[COD].md

# ============================================================
# LIBRETTO [NOME] ([COD]) - ARCHITETTURA
# ============================================================


---

# 1. DESCRIZIONE NON-DEV (1-3 paragrafi)

[Breve intro per chi legge questo file direttamente.
Spiega in termini semplici cosa contiene questo documento.]


---

# 2. SCHEMA DATABASE

## 2.1 Tabelle Principali

```sql
-- ============================================================
-- TABELLA: [nome_tabella]
-- Scopo: [descrizione breve]
-- ============================================================

CREATE TABLE IF NOT EXISTS app.[nome_tabella] (
  -- Chiavi
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Relazioni
  restaurant_id uuid NOT NULL REFERENCES app.restaurants(id),
  
  -- Dati core
  [campo1] text NOT NULL,           -- [descrizione campo]
  [campo2] integer NOT NULL DEFAULT 0,  -- [descrizione campo]
  
  -- Stato
  status text NOT NULL DEFAULT 'active'
    CHECK (status IN ('active', 'inactive', 'deleted')),
  
  -- Timestamp
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- COMMENTI
COMMENT ON TABLE app.[nome_tabella] IS '[descrizione dettagliata]';
COMMENT ON COLUMN app.[nome_tabella].[campo1] IS '[descrizione]';
```

## 2.2 Indici

```sql
-- Indice per lookup frequenti
CREATE INDEX IF NOT EXISTS idx_[tabella]_[campo] 
  ON app.[tabella]([campo]);

-- Indice per query composite
CREATE INDEX IF NOT EXISTS idx_[tabella]_[campo1]_[campo2] 
  ON app.[tabella]([campo1], [campo2]);
```

## 2.3 Constraints

```sql
-- Unique constraint
ALTER TABLE app.[tabella] 
  ADD CONSTRAINT uq_[tabella]_[campo] UNIQUE ([campo]);

-- Check constraint
ALTER TABLE app.[tabella] 
  ADD CONSTRAINT chk_[tabella]_[regola] CHECK ([condizione]);
```


---

# 3. DIAGRAMMA RELAZIONI

```
+-------------------+
|   restaurants     |
|-------------------|
| id (PK)           |
| name              |
+--------+----------+
         | 1:N
         |
         v
+-------------------+         +-------------------+
|  [tabella_1]      |---------|  [tabella_2]      |
|-------------------|   N:1   |-------------------|
| id (PK)           |         | id (PK)           |
| restaurant_id     |         | [campo]           |
| [altri campi]     |         | [altri campi]     |
+-------------------+         +-------------------+
```


---

# 4. ENUM E TIPI

```sql
-- Tipo: [nome_tipo]
-- Scopo: [descrizione]
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = '[nome_tipo]') THEN
    CREATE TYPE app.[nome_tipo] AS ENUM (
      'valore1',  -- [significato]
      'valore2',  -- [significato]
      'valore3'   -- [significato]
    );
  END IF;
END $$;
```


---

# 5. VIEWS

```sql
-- View: vw_[nome]
-- Scopo: [descrizione]
-- Usata da: [altri moduli]
CREATE OR REPLACE VIEW app.vw_[nome] AS
SELECT 
  t.id,
  t.[campo1],
  t.[campo2],
  r.name AS restaurant_name
FROM app.[tabella] t
JOIN app.restaurants r ON r.id = t.restaurant_id
WHERE t.status = 'active';

-- Permessi (solo lettura)
GRANT SELECT ON app.vw_[nome] TO authenticated;
```


---

# 6. INVARIANTI (Regole sempre vere)

| # | Invariante | Descrizione | Enforcement |
|---|------------|-------------|-------------|
| 1 | [regola] | [spiegazione] | CHECK / TRIGGER / RPC |
| 2 | [regola] | [spiegazione] | CHECK / TRIGGER / RPC |
| 3 | [regola] | [spiegazione] | CHECK / TRIGGER / RPC |

```sql
-- Trigger per enforce invariante [N]
CREATE OR REPLACE FUNCTION app.trg_enforce_[invariante]()
RETURNS TRIGGER AS $$
BEGIN
  IF [condizione_violata] THEN
    RAISE EXCEPTION '[messaggio errore]';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_[tabella]_[invariante]
  BEFORE INSERT OR UPDATE ON app.[tabella]
  FOR EACH ROW EXECUTE FUNCTION app.trg_enforce_[invariante]();
```


---

# === CHECKPOINT-B ===

## Verifica Completezza

| Elemento | Atteso | Presente | Status |
|----------|--------|----------|--------|
| Descrizione non-dev | 1-3 para | _ | [OK/FAIL] |
| Tabelle SQL | N tabelle | _ | [OK/FAIL] |
| Indici | N indici | _ | [OK/FAIL] |
| Diagramma relazioni | 1 | _ | [OK/FAIL] |
| Enum/Tipi | N tipi | _ | [OK/FAIL] |
| Views | N views | _ | [OK/FAIL] |
| Invarianti | N regole | _ | [OK/FAIL] |

## Firma

| Campo | Valore |
|-------|--------|
| Sezione | B |
| Data | [GGMMAA-HHMM] |
| Status | COMPLETO/PARZIALE/INCOMPLETO |

---

# ============================================================
# FINE B-ARCHITETTURA
# ============================================================
```


---

# === CHECKPOINT PARTE 4 (SEZ 9-10) ===

## Verifica Contenuti da TEMPLATE-STRUTTURA

| Elemento | Fonte (righe) | Presente | Status |
|----------|---------------|----------|--------|
| Template A completo | TEMPL 35-193 | SI | OK |
| Header (7 campi) | TEMPL 50-61 | SI | OK |
| Funzioni tabella | TEMPL 65-74 | SI | OK |
| Descrizione non-dev | TEMPL 79-100 | SI | OK |
| Investitori (4 sezioni) | TEMPL 105-127 | SI | OK |
| Documenti correlati | TEMPL 132-154 | SI | OK |
| Strumenti valutazione | TEMPL 159-185 | SI | OK |
| CHECKPOINT-A | TEMPL 190-193 | SI | OK |
| Template B completo | TEMPL 205-383 | SI | OK |
| Schema SQL tabelle | TEMPL 227-256 | SI | OK |
| Indici + Constraints | TEMPL 258-280 | SI | OK |
| Diagramma relazioni | TEMPL 287-304 | SI | OK |
| Enum/Tipi | TEMPL 311-324 | SI | OK |
| Views | TEMPL 331-347 | SI | OK |
| Invarianti | TEMPL 352-375 | SI | OK |
| CHECKPOINT-B | TEMPL 380-383 | SI | OK |

## Conteggio

| Metrica | Valore |
|---------|--------|
| Righe aggiunte | ~320 |
| Tabelle | 12 |
| Code block | 10 |

## Integrita'

- [x] Nessun [TODO]
- [x] Nessun [DA COMPLETARE]
- [x] Code block chiusi
- [x] Tabelle complete

**CHECKPOINT PARTE 4: PASS**

---


# ============================================================
# SEZIONE 11: TEMPLATE C - IMPLEMENTAZIONE (500-1000 righe)
# ============================================================
# Scopo: Codice eseguibile + Istruzioni dettagliate
# Audience: Dev che implementa, AI che genera codice
# ============================================================

```markdown
# C-IMPLEMENTAZIONE-[COD].md

# ============================================================
# LIBRETTO [NOME] ([COD]) - IMPLEMENTAZIONE
# ============================================================


---

# STRUTTURA PER OGNI FEATURE

Per ogni funzionalita', seguire questo schema:

```
+-------------------------------------------------------------+
| FEATURE: [Nome Feature]                                     |
+-------------------------------------------------------------+
|                                                             |
| DESCRIZIONE NON-DEV:                                        |
| [1-3 paragrafi in linguaggio semplice]                      |
|                                                             |
| ISTRUZIONE GENERALE:                                        |
| [Cosa deve succedere ad alto livello - 1-2 frasi]           |
|                                                             |
| ISTRUZIONI DETTAGLIATE:                                     |
| 1. [Step con codice]                                        |
| 2. [Step con codice]                                        |
| N. [Step con codice]                                        |
|                                                             |
| GUARD RAIL:                                                 |
| [SQL/Function che previene errori]                          |
|                                                             |
| DO NOT:                                                     |
| - MAI [azione pericolosa]                                   |
|                                                             |
| DO:                                                         |
| - SEMPRE [best practice]                                    |
|                                                             |
+-------------------------------------------------------------+
```


---

# FEATURE 1: [Nome]

## Descrizione Non-Dev

[Cosa fa questa feature in termini semplici.
Esempio pratico di quando viene usata.]

## Istruzione Generale

[Cosa deve succedere - 1-2 frasi]

## Istruzioni Dettagliate

### Step 1: [Nome step]

```sql
-- [Descrizione]
[codice SQL]
```

### Step 2: [Nome step]

```typescript
// [Descrizione]
[codice TypeScript per Worker]
```

### Step N: [Nome step]

```sql
-- [Descrizione]
[codice]
```

## Guard Rail

```sql
-- Previene: [cosa previene]
-- Trigger/Constraint che blocca operazioni errate

CREATE OR REPLACE FUNCTION app.guard_[nome]()
RETURNS TRIGGER AS $$
BEGIN
  -- Validazione
  IF [condizione_errore] THEN
    RAISE EXCEPTION '[COD]-001: [messaggio]';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;
```

## DO NOT

- MAI [azione pericolosa 1 specifica per questa feature]
- MAI [azione pericolosa 2]
- MAI [azione pericolosa 3]

## DO

- SEMPRE [best practice 1]
- SEMPRE [best practice 2]
- SEMPRE [best practice 3]


---

# FEATURE 2: [Nome]

[Ripetere struttura sopra per ogni feature]


---

# FUNCTIONS / RPC

## [nome_funzione]

```sql
-- ============================================================
-- FUNCTION: app.[nome_funzione]
-- Scopo: [descrizione]
-- Chiamata da: [Worker/Frontend/Altro modulo]
-- ============================================================

CREATE OR REPLACE FUNCTION app.[nome_funzione](
  p_param1 uuid,
  p_param2 text,
  p_idempotency_key text DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = app, pg_temp
AS $$
DECLARE
  v_result jsonb;
BEGIN
  -- 1. Validazione input
  IF p_param1 IS NULL THEN
    RAISE EXCEPTION '[COD]-001: param1 required';
  END IF;
  
  -- 2. Idempotenza (se applicabile)
  IF p_idempotency_key IS NOT NULL THEN
    -- Check esistenza operazione
    IF EXISTS (
      SELECT 1 FROM app.idempotency_log 
      WHERE key = p_idempotency_key
    ) THEN
      -- Ritorna risultato precedente
      SELECT result INTO v_result 
      FROM app.idempotency_log 
      WHERE key = p_idempotency_key;
      RETURN v_result;
    END IF;
  END IF;
  
  -- 3. Logica core
  [implementazione]
  
  -- 4. Salva idempotency (se applicabile)
  IF p_idempotency_key IS NOT NULL THEN
    INSERT INTO app.idempotency_log (key, result, created_at)
    VALUES (p_idempotency_key, v_result, now());
  END IF;
  
  -- 5. Return
  RETURN jsonb_build_object(
    'ok', true,
    'data', v_result
  );
  
EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object(
    'ok', false,
    'error', SQLERRM,
    'code', SQLSTATE
  );
END;
$$;

-- Permessi
REVOKE ALL ON FUNCTION app.[nome_funzione] FROM PUBLIC;
GRANT EXECUTE ON FUNCTION app.[nome_funzione] TO service_role;
```


---

# TRIGGERS

## [nome_trigger]

```sql
-- ============================================================
-- TRIGGER: trg_[nome]
-- Scopo: [descrizione]
-- Tabella: app.[tabella]
-- ============================================================

CREATE OR REPLACE FUNCTION app.trg_[nome]()
RETURNS TRIGGER AS $$
BEGIN
  -- Logica trigger
  [implementazione]
  
  RETURN NEW; -- o OLD per DELETE
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_[tabella]_[nome]
  [BEFORE|AFTER] [INSERT|UPDATE|DELETE] ON app.[tabella]
  FOR EACH ROW EXECUTE FUNCTION app.trg_[nome]();
```


---

# WORKERS (Netlify/Railway (stack))

## [nome-worker]

```typescript
// ============================================================
// WORKER: [nome-worker]
// Scopo: [descrizione]
// Endpoint: [metodo] /api/[path]
// ============================================================

import { Hono } from 'hono';
import { neon } from '@neondatabase/serverless';
import { z } from 'zod';

// Types
interface Env {
  DATABASE_URL: string;
  CLERK_SECRET_KEY: string;
}

// Validation schema
const RequestSchema = z.object({
  [campo]: z.string().min(1).max(100),
  [campo2]: z.number().int().positive(),
});

const app = new Hono<{ Bindings: Env }>();

// Middleware: Auth check
app.use('*', async (c, next) => {
  // Validazione JWT Ordini-Lampo Auth (custom session-cookie)
  const authHeader = c.req.header('Authorization');
  if (!authHeader?.startsWith('Bearer ')) {
    return c.json({ ok: false, error: 'Unauthorized' }, 401);
  }
  
  // TODO: Verify JWT with Ordini-Lampo Auth (custom session-cookie)
  await next();
});

// Handler: [nome]
app.post('/api/v1/[path]', async (c) => {
  const sql = neon(c.env.DATABASE_URL);
  
  try {
    // 1. Parse input
    const body = await c.req.json();
    
    // 2. Validazione con Zod
    const validated = RequestSchema.parse(body);
    
    // 3. Chiamata DB
    const result = await sql`
      SELECT app.[funzione](
        ${validated.param1}::uuid,
        ${validated.param2}::text
      ) as result
    `;
    
    // 4. Parse risultato
    const dbResult = result[0]?.result;
    
    if (!dbResult?.ok) {
      return c.json({ ok: false, error: dbResult?.error }, 400);
    }
    
    // 5. Response
    return c.json({ ok: true, data: dbResult.data });
    
  } catch (error) {
    // Zod validation error
    if (error instanceof z.ZodError) {
      return c.json({ ok: false, error: error.errors }, 400);
    }
    
    // Generic error
    console.error('[COD] Error:', error);
    return c.json({ ok: false, error: 'Internal server error' }, 500);
  }
});

export default app;
```


---

# MIGRAZIONI

## 001_[cod]_init.sql

```sql
-- ============================================================
-- MIGRAZIONE: 001_[cod]_init.sql
-- Scopo: Setup iniziale modulo [COD]
-- Data: [DD/MM/YYYY]
-- Autore: [Nome]
-- Rollback: 001_[cod]_rollback.sql
-- ============================================================

-- Pre-check
DO $$
BEGIN
  -- Verifica dipendenze
  IF NOT EXISTS (SELECT 1 FROM pg_tables WHERE tablename = 'restaurants') THEN
    RAISE EXCEPTION 'Tabella restaurants non esiste. Eseguire migrazione COR prima.';
  END IF;
END $$;

-- Schema
CREATE SCHEMA IF NOT EXISTS app;

-- Tabelle
[CREATE TABLE statements]

-- Indici
[CREATE INDEX statements]

-- Funzioni
[CREATE FUNCTION statements]

-- Trigger
[CREATE TRIGGER statements]

-- RLS
ALTER TABLE app.[tabella] ENABLE ROW LEVEL SECURITY;
[CREATE POLICY statements]

-- Grants
GRANT USAGE ON SCHEMA app TO authenticated;
GRANT SELECT ON app.[tabella] TO authenticated;

-- Post-check
DO $$
BEGIN
  -- Verifica migrazione
  IF NOT EXISTS (SELECT 1 FROM pg_tables WHERE tablename = '[tabella]') THEN
    RAISE EXCEPTION 'Migrazione [COD] fallita: tabella non creata';
  END IF;
  
  RAISE NOTICE 'Migrazione 001_[cod]_init completata';
END $$;
```

## 001_[cod]_rollback.sql

```sql
-- ============================================================
-- ROLLBACK: 001_[cod]_rollback.sql
-- Ripristina stato pre-migrazione 001
-- ATTENZIONE: Perdera' tutti i dati nelle tabelle [COD]
-- ============================================================

-- Conferma
DO $$
BEGIN
  RAISE WARNING 'Rollback [COD]: tutti i dati verranno persi!';
END $$;

-- Drop in ordine inverso
DROP TRIGGER IF EXISTS trg_[nome] ON app.[tabella];
DROP FUNCTION IF EXISTS app.[funzione];
DROP TABLE IF EXISTS app.[tabella] CASCADE;

-- Verifica rollback
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_tables WHERE tablename = '[tabella]') THEN
    RAISE EXCEPTION 'Rollback [COD] fallito: tabella ancora presente';
  END IF;
  
  RAISE NOTICE 'Rollback 001_[cod] completato';
END $$;
```


---

# === CHECKPOINT-C ===

## Verifica Completezza

| Elemento | Atteso | Presente | Status |
|----------|--------|----------|--------|
| Features | N features | _ | [OK/FAIL] |
| Functions SQL | N funzioni | _ | [OK/FAIL] |
| SECURITY DEFINER | Tutte | _ | [OK/FAIL] |
| search_path | Tutte | _ | [OK/FAIL] |
| Triggers | N triggers | _ | [OK/FAIL] |
| Workers TS | N handlers | _ | [OK/FAIL] |
| Validazione Zod | Tutti endpoint | _ | [OK/FAIL] |
| Migrazioni | N file | _ | [OK/FAIL] |
| Rollback | N file | _ | [OK/FAIL] |
| DO NOT per feature | Min 3 | _ | [OK/FAIL] |
| DO per feature | Min 3 | _ | [OK/FAIL] |

## Firma

| Campo | Valore |
|-------|--------|
| Sezione | C |
| Data | [GGMMAA-HHMM] |
| Status | COMPLETO/PARZIALE/INCOMPLETO |

---

# ============================================================
# FINE C-IMPLEMENTAZIONE
# ============================================================
```


---

# === CHECKPOINT PARTE 5 (SEZ 11) ===

## Verifica Contenuti da TEMPLATE-STRUTTURA

| Elemento | Fonte (righe) | Presente | Status |
|----------|---------------|----------|--------|
| Struttura feature | TEMPL 405-435 | SI | OK |
| Template feature completo | TEMPL 440-502 | SI | OK |
| Functions SQL con SECURITY DEFINER | TEMPL 518-568 | SI + IDEMPOTENCY | OK |
| Triggers template | TEMPL 575-595 | SI | OK |
| Workers TypeScript | TEMPL 602-649 | SI + ZOD | OK |
| Migrazioni numerate | TEMPL 656-667 | SI + PRE/POST CHECK | OK |
| Rollback scripts | TEMPL 669-678 | SI + VERIFICA | OK |
| DO NOT / DO per feature | TEMPL 492-502 | SI | OK |
| CHECKPOINT-C | TEMPL 683-686 | SI | OK |

## Conteggio

| Metrica | Valore |
|---------|--------|
| Righe aggiunte | ~340 |
| Tabelle | 2 |
| Code block | 9 |

## Integrita'

- [x] Nessun [TODO] (tranne placeholder intenzionali)
- [x] Nessun [DA COMPLETARE]
- [x] Code block chiusi
- [x] Tabelle complete
- [x] SECURITY DEFINER presente
- [x] search_path presente
- [x] Zod validation presente
- [x] Idempotency pattern presente

**CHECKPOINT PARTE 5: PASS**

---


# ============================================================
# SEZIONE 12: TEMPLATE D - GUARDRAIL (200-400 righe)
# ============================================================
# Scopo: Sicurezza + Protezioni + DO NOT / DO
# Audience: Tutti (dev, reviewer, ops)
# ============================================================

```markdown
# D-GUARDRAIL-[COD].md

# ============================================================
# LIBRETTO [NOME] ([COD]) - GUARDRAIL
# ============================================================


---

# 1. DESCRIZIONE NON-DEV

[Spiegazione semplice di cosa sono i guardrail e perche' servono.
"I guardrail sono come le barriere di sicurezza in autostrada..."]


---

# 2. RLS POLICIES

## Policy: [nome_policy]

```sql
-- ============================================================
-- RLS POLICY: [nome]
-- Tabella: app.[tabella]
-- Ruolo: authenticated
-- Operazione: SELECT / INSERT / UPDATE / DELETE
-- ============================================================

-- Abilita RLS
ALTER TABLE app.[tabella] ENABLE ROW LEVEL SECURITY;

-- Policy SELECT
CREATE POLICY "[tabella]_select" ON app.[tabella]
  FOR SELECT
  TO authenticated
  USING (
    restaurant_id = (current_setting('app.current_restaurant_id'))::uuid
  );

-- Policy INSERT
CREATE POLICY "[tabella]_insert" ON app.[tabella]
  FOR INSERT
  TO authenticated
  WITH CHECK (
    restaurant_id = (current_setting('app.current_restaurant_id'))::uuid
  );

-- Policy UPDATE
CREATE POLICY "[tabella]_update" ON app.[tabella]
  FOR UPDATE
  TO authenticated
  USING (
    restaurant_id = (current_setting('app.current_restaurant_id'))::uuid
  )
  WITH CHECK (
    restaurant_id = (current_setting('app.current_restaurant_id'))::uuid
  );

-- Policy DELETE (se permesso)
CREATE POLICY "[tabella]_delete" ON app.[tabella]
  FOR DELETE
  TO authenticated
  USING (
    restaurant_id = (current_setting('app.current_restaurant_id'))::uuid
  );

-- Test policy
-- Utente A non deve vedere dati utente B
```

## Matrice Permessi

| Tabella | anon | authenticated | service_role |
|---------|------|---------------|--------------|
| [tab1] | NO | SELECT | ALL |
| [tab2] | NO | SELECT, INSERT | ALL |
| [tab3] | NO | NO | ALL |


---

# 3. RATE LIMITING

| Endpoint | Per IP | Per Restaurant | Per Device | Burst |
|----------|--------|----------------|------------|-------|
| [endpoint1] | 10/min | 50/min | 5/min | 3 |
| [endpoint2] | 5/min | 20/min | 3/min | 2 |

```typescript
// Implementazione rate limit
import { RateLimiter } from '@/lib/rate-limit';

const limiter = new RateLimiter({
  windowMs: 60 * 1000, // 1 minuto
  max: 10,
  keyGenerator: (c) => {
    // Priorita': device > restaurant > IP
    const deviceId = c.req.header('X-Device-ID');
    const restaurantId = c.req.header('X-Restaurant-ID');
    const ip = c.req.header('CF-Connecting-IP');
    
    return deviceId || restaurantId || ip || 'anonymous';
  },
  handler: (c) => {
    return c.json({ 
      ok: false, 
      error: 'Too many requests',
      retryAfter: 60
    }, 429);
  }
});
```


---

# 4. VALIDAZIONE INPUT

```typescript
// Schema validazione con Zod
import { z } from 'zod';

// Schema principale
export const [Nome]Schema = z.object({
  [campo1]: z.string()
    .min(1, '[campo1] richiesto')
    .max(100, '[campo1] troppo lungo'),
  
  [campo2]: z.number()
    .int('[campo2] deve essere intero')
    .positive('[campo2] deve essere positivo'),
  
  [campo3]: z.enum(['value1', 'value2'], {
    errorMap: () => ({ message: 'Valore non valido per [campo3]' })
  }),
  
  [campo_opzionale]: z.string().optional(),
});

// Tipo derivato
export type [Nome]Input = z.infer<typeof [Nome]Schema>;

// Uso nel handler
const validated = [Nome]Schema.parse(input);
```


---

# 5. DO NOT LIST (CRITICA)

```
+==============================================================+
|       !! AZIONI VIETATE - LEGGERE PRIMA DI CODIFICARE !!     |
+==============================================================+
|                                                              |
|  GENERICI (tutti i moduli):                                  |
|  - MAI esporre service_role key al frontend                  |
|  - MAI disabilitare RLS su tabelle con dati utente           |
|  - MAI UPDATE/DELETE su tabelle append-only                  |
|  - MAI hardcodare secrets nel codice                         |
|  - MAI loggare PII (email, telefono, P.IVA, importi)         |
|  - MAI bypassare validazione input                           |
|                                                              |
|  SPECIFICI [COD]:                                            |
|  - MAI [azione vietata specifica modulo 1]                   |
|  - MAI [azione vietata specifica modulo 2]                   |
|  - MAI [azione vietata specifica modulo 3]                   |
|  - MAI [azione vietata specifica modulo 4]                   |
|                                                              |
+==============================================================+
```


---

# 6. DO LIST (BEST PRACTICE)

```
+==============================================================+
|              AZIONI OBBLIGATORIE                             |
+==============================================================+
|                                                              |
|  GENERICI (tutti i moduli):                                  |
|  - SEMPRE usare idempotency_key per operazioni critiche      |
|  - SEMPRE validare input prima di processare                 |
|  - SEMPRE usare SECURITY DEFINER + search_path               |
|  - SEMPRE loggare errori con context (no PII)                |
|  - SEMPRE usare advisory lock per op. concorrenti            |
|                                                              |
|  SPECIFICI [COD]:                                            |
|  - SEMPRE [best practice specifica modulo 1]                 |
|  - SEMPRE [best practice specifica modulo 2]                 |
|  - SEMPRE [best practice specifica modulo 3]                 |
|  - SEMPRE [best practice specifica modulo 4]                 |
|                                                              |
+==============================================================+
```


---

# 7. INCIDENTI COMUNI + FIX

| # | Scenario | Causa | Fix |
|---|----------|-------|-----|
| 1 | [descrizione incidente] | [perche' succede] | [come risolvere] |
| 2 | [descrizione incidente] | [perche' succede] | [come risolvere] |
| 3 | [descrizione incidente] | [perche' succede] | [come risolvere] |


---

# 8. AUDIT CHECKLIST SICUREZZA

| # | Check | Query/Test | Atteso |
|---|-------|------------|--------|
| 1 | RLS attivo | `SELECT tablename, rowsecurity FROM pg_tables WHERE schemaname = 'app'` | Tutte true |
| 2 | No permessi anon | `SELECT * FROM information_schema.role_table_grants WHERE grantee = 'anon'` | 0 righe |
| 3 | SECURITY DEFINER | `SELECT proname, prosecdef FROM pg_proc WHERE pronamespace = 'app'::regnamespace` | Tutte true |
| 4 | search_path | `SELECT proname, proconfig FROM pg_proc WHERE pronamespace = 'app'::regnamespace` | Contiene search_path |


---

# === CHECKPOINT-D ===

## Verifica Completezza

| Elemento | Atteso | Presente | Status |
|----------|--------|----------|--------|
| Descrizione non-dev | 1 para | _ | [OK/FAIL] |
| RLS Policies | N policies | _ | [OK/FAIL] |
| Matrice permessi | 1 tabella | _ | [OK/FAIL] |
| Rate limiting | Configurazione | _ | [OK/FAIL] |
| Validazione Zod | Schema completo | _ | [OK/FAIL] |
| DO NOT | Min 10 | _ | [OK/FAIL] |
| DO | Min 10 | _ | [OK/FAIL] |
| Incidenti comuni | Min 3 | _ | [OK/FAIL] |
| Audit checklist | Min 4 | _ | [OK/FAIL] |

## Firma

| Campo | Valore |
|-------|--------|
| Sezione | D |
| Data | [GGMMAA-HHMM] |
| Status | COMPLETO/PARZIALE/INCOMPLETO |

---

# ============================================================
# FINE D-GUARDRAIL
# ============================================================
```


---

# ============================================================
# SEZIONE 13: TEMPLATE E - CHECKLIST (300-500 righe)
# ============================================================
# Scopo: Audit + Esito reale + Errori + Migliorie
# Audience: Auditor, QA, orchestratore
# ============================================================

```markdown
# E-CHECKLIST-[COD].md

# ============================================================
# LIBRETTO [NOME] ([COD]) - CHECKLIST AUDIT
# ============================================================
# Data Audit: [DD/MM/YYYY]
# Auditor: [Nome]
# Versione Libretto: [X.X]
# ============================================================


---

# 1. CHECK CORE (51 universali)

## PKG - Pacchetto (6)

| ID | Check | Esito | Note |
|----|-------|-------|------|
| PKG-01 | Package.json presente | [PASS/FAIL/PARZIALE/N-A] | |
| PKG-02 | Dipendenze bloccate | | |
| PKG-03 | Script build funziona | | |
| PKG-04 | Script test funziona | | |
| PKG-05 | No dipendenze vulnerabili | | |
| PKG-06 | TypeScript strict | | |

## ENV - Ambienti (5)

| ID | Check | Esito | Note |
|----|-------|-------|------|
| ENV-01 | .env.example presente | | |
| ENV-02 | Staging configurato | | |
| ENV-03 | Production configurato | | |
| ENV-04 | Secrets in vault | | |
| ENV-05 | Variabili documentate | | |

## DB - Database (10)

| ID | Check | Esito | Note |
|----|-------|-------|------|
| DB-01 | Schema app esiste | | |
| DB-02 | Migrazioni numerate | | |
| DB-03 | Rollback presenti | | |
| DB-04 | RLS attivo | | |
| DB-05 | Indici verificati | | |
| DB-06 | FK con ON DELETE | | |
| DB-07 | Trigger updated_at | | |
| DB-08 | COMMENT su tabelle | | |
| DB-09 | No query N+1 | | |
| DB-10 | Connection pooling | | |

## SEC - Sicurezza (8)

| ID | Check | Esito | Note |
|----|-------|-------|------|
| SEC-01 | SECURITY DEFINER | | |
| SEC-02 | search_path | | |
| SEC-03 | Input validation | | |
| SEC-04 | Rate limiting | | |
| SEC-05 | No PII in log | | |
| SEC-06 | JWT validation | | |
| SEC-07 | CORS configurato | | |
| SEC-08 | Kill-switch | | |

## RUN - Runtime (5)

| ID | Check | Esito | Note |
|----|-------|-------|------|
| RUN-01 | Cold start < 1s | | |
| RUN-02 | Memory < 128MB | | |
| RUN-03 | Timeout gestito | | |
| RUN-04 | Error handling | | |
| RUN-05 | Health endpoint | | |

## OBS - Osservabilita' (4)

| ID | Check | Esito | Note |
|----|-------|-------|------|
| OBS-01 | Logging strutturato | | |
| OBS-02 | Correlation ID | | |
| OBS-03 | Metriche esposte | | |
| OBS-04 | Alert configurati | | |

## DATA - Integrita' (4)

| ID | Check | Esito | Note |
|----|-------|-------|------|
| DATA-01 | Idempotency key | | |
| DATA-02 | Transazioni ACID | | |
| DATA-03 | Constraint CHECK | | |
| DATA-04 | Soft delete | | |

## REC - Recovery (3)

| ID | Check | Esito | Note |
|----|-------|-------|------|
| REC-01 | Backup automatico | | |
| REC-02 | PITR disponibile | | |
| REC-03 | Restore testato | | |

## LIVE - Go-Live (4)

| ID | Check | Esito | Note |
|----|-------|-------|------|
| LIVE-01 | Smoke test staging | | |
| LIVE-02 | Load test | | |
| LIVE-03 | Rollback plan | | |
| LIVE-04 | Runbook presente | | |

## OPS - Operazioni (2)

| ID | Check | Esito | Note |
|----|-------|-------|------|
| OPS-01 | Documentazione | | |
| OPS-02 | Contatti emergenza | | |


---

# 2. SENTINEL (9 specifici modulo)

| ID | Sentinel | Cosa Verifica | Query/Test | Atteso | Esito | Note |
|----|----------|---------------|------------|--------|-------|------|
| [COD]-01 | Core Function | [descrizione] | [query] | [atteso] | | |
| [COD]-02 | Dependencies | [descrizione] | [query] | [atteso] | | |
| [COD]-03 | Data Integrity | [descrizione] | [query] | [atteso] | | |
| [COD]-04 | Security | [descrizione] | [query] | [atteso] | | |
| [COD]-05 | Performance | [descrizione] | [query] | [atteso] | | |
| [COD]-06 | Error Handling | [descrizione] | [query] | [atteso] | | |
| [COD]-07 | Integration | [descrizione] | [query] | [atteso] | | |
| [COD]-08 | Audit Trail | [descrizione] | [query] | [atteso] | | |
| [COD]-09 | Recovery | [descrizione] | [query] | [atteso] | | |


---

# 3. ESITO REALE OPERATIVO

## Riepilogo Esecuzione

| Campo | Valore |
|-------|--------|
| Data esecuzione | [DD/MM/YYYY HH:MM] |
| Esecutore | [Nome persona/AI] |
| Ambiente | [staging / prod] |
| Durata audit | [XX minuti] |

## Conteggio

| Categoria | PASS | FAIL | PARZIALE | N/A |
|-----------|------|------|----------|-----|
| CORE (51) | | | | |
| SENTINEL (9) | | | | |
| **TOTALE (60)** | | | | |

## Score Calcolato

```
PASS:     __
PARZIALE: __ (x 0.5 = __)
N/A:      __
VALIDI:   60 - __ = __

SCORE: (__ + __) / __ x 100 = __/100

LIVELLO: [PLATINUM/GOLD/SILVER/BRONZE/FAIL]
```


---

# 4. ERRORI TROVATI

| # | ID Check | Descrizione Errore | Impatto | Priorita' | Fix Applicato |
|---|----------|-------------------|---------|----------|---------------|
| 1 | [ID] | [descrizione] | [Alto/Medio/Basso] | P0/P1/P2 | [SI/NO] |
| 2 | | | | | |
| 3 | | | | | |


---

# 5. AZIONI SOSPESE

| # | Azione | Motivo Sospensione | Owner | Deadline | Stato |
|---|--------|-------------------|-------|----------|-------|
| 1 | [azione] | [motivo: complessita'/dubbio/dipendenza] | [nome] | [data] | SOSPESO |
| 2 | | | | | |


---

# 6. DUBBI INTERPRETATIVI

| # | Area | Dubbio | Decisione Presa | Data |
|---|------|--------|-----------------|------|
| 1 | [area] | [domanda] | [risposta/decisione] | [data] |
| 2 | | | | |


---

# 7. SUGGERIMENTI MIGLIORAMENTO

| # | Tipo | Suggerimento | Priorita' | Effort | Impatto |
|---|------|--------------|----------|--------|---------|
| 1 | SNELLIMENTO | [ridurre/semplificare X] | P1/P2/P3 | Basso/Medio/Alto | [descrizione] |
| 2 | CHIARIMENTO | [chiarire regola Y] | | | |
| 3 | CONTROLLO | [aggiungere verifica Z] | | | |
| 4 | TECNICO | [miglioramento codice] | | | |

### Legenda Tipi

- **SNELLIMENTO**: Rimuovere ridondanze, semplificare
- **CHIARIMENTO**: Rendere regole piu' chiare
- **CONTROLLO**: Aggiungere verifica automatica
- **TECNICO**: Miglioramento codice/architettura


---

# 8. VERDETTO FINALE

## Risultato

| Campo | Valore |
|-------|--------|
| Modulo | [COD] - [NOME] |
| Versione | [X.X] |
| Score DOC | __/100 |
| Score MOD | __/100 |
| Livello | [PLATINUM / GOLD / SILVER / BRONZE / FAIL] |
| FAIL Critici (P0) | __ |
| FAIL Totali | __ |

## Verdetto

- [ ] **GO** - Pronto per produzione
- [ ] **GO CON RISERVA** - Produzione OK, fix P1 entro 2 settimane
- [ ] **NO-GO** - Fix P0 obbligatori prima del deploy

## Condizioni (se GO CON RISERVA)

| # | Condizione | Deadline |
|---|------------|----------|
| 1 | [fix richiesto] | [data] |
| 2 | | |


---

# 9. FIRMA AUDIT

| Ruolo | Nome | Data | Firma |
|-------|------|------|-------|
| Auditor | | | |
| Reviewer | | | |
| Approvatore (Paolo) | | | |


---

# === CHECKPOINT-E ===

## Verifica Completezza

| Elemento | Atteso | Presente | Status |
|----------|--------|----------|--------|
| 51 CHECK CORE | 51 righe | _ | [OK/FAIL] |
| 9 SENTINEL | 9 righe | _ | [OK/FAIL] |
| Conteggio | Tabella completa | _ | [OK/FAIL] |
| Score calcolato | Formula applicata | _ | [OK/FAIL] |
| Errori trovati | Lista compilata | _ | [OK/FAIL] |
| Azioni sospese | Lista o N/A | _ | [OK/FAIL] |
| Suggerimenti | Min 1 | _ | [OK/FAIL] |
| Verdetto | GO/NO-GO | _ | [OK/FAIL] |
| Firme | 3 ruoli | _ | [OK/FAIL] |

## Firma

| Campo | Valore |
|-------|--------|
| Sezione | E |
| Data | [GGMMAA-HHMM] |
| Status | COMPLETO/PARZIALE/INCOMPLETO |

---

# ============================================================
# FINE E-CHECKLIST
# ============================================================
```


---

# ############################################################
# APPENDICE: QUICK REFERENCE
# ############################################################


---

# ============================================================
# QUICK REFERENCE - STAMPA QUESTA PAGINA
# ============================================================

## SOGLIE

```
DOC: >= 93/100  (documentazione)
MOD: >= 96/100  (software)
PLATINUM: DOC >= 93 AND MOD >= 96
```

## RANGE RIGHE

```
A-INTRO:          max 200 righe
B-ARCHITETTURA:   300-500 righe
C-IMPLEMENTAZIONE: 500-1000 righe
D-GUARDRAIL:      200-400 righe
E-CHECKLIST:      300-500 righe

TOTALE LIBRETTO: 1500-2600 righe (5 file)
```

## CHECKLIST NUMERICA

```
51 CHECK CORE (universali)
9+ SENTINEL (specifici modulo)
20 ERRORI FATALI (DO NOT)
30 PUNTI PRE-SUBMIT
241 CHECK TOTALI (51 + 190)
```

## 7 REGOLE D'ORO

```
1. Meglio o Niente
2. Audit prima, codice poi
3. Single source of truth
4. Doppia valutazione
5. DO NOT > DO
6. Non-dev first
7. Checkpoint obbligatorio
```

## FORMULA SCORE

```
Score = (PASS + PARZIALE x 0.5) / (60 - N/A) x 100
```

## LIVELLI

```
PLATINUM  96-100  TARGET
GOLD      90-95   Quasi pronto
SILVER    81-89   Staging only
BRONZE    70-80   Dev only
FAIL      <70     Riscrivere
```

## NAMING FILE

```
LIBRETTO-[COD]-V[X.X]-[GGMMAA]-[HHMM].md
Esempio: LIBRETTO-COR-V1.0-241224-1800.md
```

## ORDINE COMPILAZIONE

```
1. A-INTRO      -> Scope
2. B-ARCHITETTURA -> DB first
3. D-GUARDRAIL  -> Regole
4. C-IMPLEMENTAZIONE -> Codice
5. E-CHECKLIST  -> Audit last
```

## I 21 MODULI STARGRID

```
CORE (15):
SHW PAS ENG COR MNU VAU MSG RAD AUD
NTF STK EGS OBS PAY SUP

COLLATERALI (6):
GOV TAR LEG MKT OPS GRD
```


---

# === CHECKPOINT PARTE 6 FINALE ===

## Verifica Contenuti da TEMPLATE-STRUTTURA

| Elemento | Fonte (righe) | Presente | Status |
|----------|---------------|----------|--------|
| Template D completo | TEMPL 698-866 | SI | OK |
| RLS Policies | TEMPL 720-741 | SI | OK |
| Matrice permessi | TEMPL 745-749 | SI | OK |
| Rate limiting | TEMPL 756-773 | SI | OK |
| Validazione Zod | TEMPL 780-792 | SI | OK |
| DO NOT (box) | TEMPL 799-815 | SI | OK |
| DO (box) | TEMPL 822-836 | SI | OK |
| Incidenti comuni | TEMPL 843-847 | SI | OK |
| Audit checklist sicurezza | TEMPL 854-858 | SI | OK |
| CHECKPOINT-D | TEMPL 863-866 | SI | OK |
| Template E completo | TEMPL 878-1041 | SI | OK |
| 51 CHECK CORE (10 categorie) | TEMPL 892-930 | SI TUTTI 51 | OK |
| 9 SENTINEL | TEMPL 900-908 | SI | OK |
| Esito reale | TEMPL 913-943 | SI | OK |
| Score formula | TEMPL 934-943 | SI | OK |
| Errori/Azioni/Dubbi/Suggerimenti | TEMPL 948-993 | SI | OK |
| Verdetto finale | TEMPL 998-1022 | SI | OK |
| Firme | TEMPL 1027-1033 | SI | OK |
| CHECKPOINT-E | TEMPL 1038-1041 | SI | OK |
| Quick Reference | META 528-572 | SI | OK |

## Conteggio Totale Documento

| Metrica | Valore |
|---------|--------|
| Righe PARTE 1 (SEZ 1-3) | ~220 |
| Righe PARTE 2 (SEZ 4-6) | ~280 |
| Righe PARTE 3 (SEZ 7-8) | ~170 |
| Righe PARTE 4 (SEZ 9-10) | ~320 |
| Righe PARTE 5 (SEZ 11) | ~340 |
| Righe PARTE 6 (SEZ 12-13 + APP) | ~450 |
| **TOTALE STIMATO** | **~1780** |

## Integrita' Finale

- [x] Nessun [TODO] (tranne placeholder intenzionali nei template)
- [x] Nessun [DA COMPLETARE]
- [x] Tutti i code block chiusi
- [x] Tutte le tabelle complete
- [x] 7 Regole d'Oro presenti
- [x] 10 Categorie OCTASTARS presenti
- [x] 51 CHECK CORE tutti dettagliati
- [x] 20 Errori Fatali presenti
- [x] 30 Punti Pre-Submit presenti
- [x] Template A completo con CHECKPOINT-A
- [x] Template B completo con CHECKPOINT-B
- [x] Template C completo con CHECKPOINT-C
- [x] Template D completo con CHECKPOINT-D
- [x] Template E completo con CHECKPOINT-E
- [x] Quick Reference presente

**CHECKPOINT PARTE 6 FINALE: PASS**


---

# ============================================================
# FIRMA DOCUMENTO FINALE
# ============================================================

| Campo | Valore |
|-------|--------|
| Documento | GUIDA-SCRITTURA-LIBRETTI-STARGRID |
| Versione | 1.0 |
| Data | 241224-1800 |
| Autore | Claude Opus 4.5 |
| Committente | Paolo Pizzo |
| Fonti | META-LIBRETTO (580r) + TEMPLATE-STRUTTURA (1067r) |
| Status | **COMPLETO E VERIFICATO** |

**TUTTI I 6 CHECKPOINT: PASS**


---

# ============================================================
# FINE DOCUMENTO
# ============================================================

---

## ✅ Patch Checklist (Stack Remap — Railway + Netlify + Stripe + Sentry)

- [ ] **(1) NO TAGLI FUNZIONALI:** testo e codice pre-esistenti sono stati mantenuti integralmente (nessuna rimozione di blocchi “funzionanti”, incluse sezioni per investitori).
- [ ] **(2) RIMOZIONE RIFERIMENTI LEGACY:** rimossi i riferimenti espliciti al vecchio stack (Auth/Edge/DB/BaaS legacy), sostituiti con nuovo stack o wording neutro.
- [ ] **(3) RIADATTAMENTO NUOVO STACK:** dove presenti direttive o snippet legati al vecchio stack, sono stati rimappati su:
  - **Railway** (API + runtime server + Postgres)
  - **Netlify** (hosting frontend / deploy)
  - **Stripe** (pagamenti)
  - **Sentry** (osservabilità — marginale)

**Nota:** hash e diff (orig vs patched) sono forniti nel report di certificazione associato a questo file.
