# ============================================================
# STARGRID MASTER PROJECT (SMP) - PARTE 1/5
# ============================================================
# SEZIONE A: INTRO + SYSTEM CONTRACT
# ============================================================
# Codice: SMP-V7.0-INTEGRATED
# Data: 24 Dicembre 2025
# Autori: Claude Opus 4.5 + ChatGPT 5.2 BULLDOZER + Claude Integration
# Committente: Paolo Pizzo - Founder Ordini-Lampo
# Target righe questa sezione: ~650
# ============================================================


---

# INDICE PARTE 1 - INTRO + SYSTEM CONTRACT

```
+==============================================================+
|              SMP PARTE 1/5 - SEZIONE A: INTRO                |
+==============================================================+
|                                                              |
|  A.1   Executive Summary                                     |
|  A.2   Vision e Mission                                      |
|  A.3   Value Proposition                                     |
|  A.4   Stakeholder Map                                       |
|  A.5   Glossario Tecnico                                     |
|  A.6   I 21 Moduli - Overview                                |
|  A.7   Grafo Dipendenze                                      |
|  A.8   Vendor Inventory + SLA                                |
|  A.9   Cost Projection                                       |
|  A.10  Success Metrics (KPI)                                 |
|  A.11  System Contract (NON negoziabile)                     |
|  A.12  SLO/SLI + Alerting Routing                            |
|  A.13  Ownership (DRI/RACI)                                  |
|  A.14  Dev Workflow                                          |
|  A.15  DR Targets (RTO/RPO)                                  |
|                                                              |
+==============================================================+
```


---

## SCOPO DOCUMENTO

Single Source of Truth per:
- Due diligence tecnica (investitori)
- Audit SOC2 (controlli + evidenze)
- Onboarding dev senior in 7 giorni
- Incident Response + Disaster Recovery (DR)

## REGOLA D'ORO

```
+----------------------------------------------------------+
|                                                          |
|  "SE NON E' ENFORCEABLE + VERIFICABILE, NON ESISTE"      |
|                                                          |
|  Enforceable: gate CI / policy DB / guardrail runtime    |
|  Verificabile: query SQL / metriche / runbook comandi    |
|                                                          |
+----------------------------------------------------------+
```


---

## A.1 EXECUTIVE SUMMARY

### Il Problema

```
+==============================================================+
|  I ristoranti italiani perdono 25-35% dei ricavi             |
|  in commissioni a Deliveroo, Glovo, JustEat.                 |
|                                                              |
|  Un ristorante con EUR 100.000/anno di delivery paga:        |
|  - EUR 25.000-35.000 in commissioni                          |
|  - Spesso il margine NETTO del ristorante                    |
|                                                              |
|  Risultato: Lavorano gratis per le piattaforme.              |
+==============================================================+
```

### La Soluzione

```
+==============================================================+
|                      ORDINI-LAMPO                            |
+==============================================================+
|                                                              |
|  Cliente scansiona QR --> Ordina via WhatsApp/Telegram       |
|  Ristorante riceve ordine DIRETTO                            |
|  Fee fissa: EUR 0.78-1.20 per ordine (vs 25-35%)             |
|                                                              |
|  RISPARMIO: EUR 20.000+/anno per ristorante medio            |
|                                                              |
+==============================================================+
```

### Numeri Chiave

| Metrica | Valore | Note |
|---------|--------|------|
| Target market | 5.000+ ristoranti | Solo Liguria iniziale |
| Fee media | EUR 0.98/ordine | Mix piani |
| Ordini medi/ristorante | 15/giorno | Conservativo |
| Revenue/ristorante/mese | EUR 441 | 15 x 30 x EUR 0.98 |
| Target 100 ristoranti | EUR 44.100/mese | Anno 1 |
| Target 500 ristoranti | EUR 220.500/mese | Anno 2 |
| Margine lordo | ~85% | Costi infra minimi |

### Stato Attuale

| Componente | Stato | Score |
|------------|-------|-------|
| Architettura | Definita | 78/100 |
| Stack tecnologico | Migrato | 82/100 |
| Documentazione | In corso | 72/100 |
| MVP funzionante | Parziale | 65/100 |
| Clienti pilota | 0 | 0/100 |
| **GLOBALE** | **NON PRONTO** | **72/100** |

### Target Lancio

| Milestone | Data | Score richiesto |
|-----------|------|-----------------|
| MVP Completo | 31 Dic 2025 | 81/100 |
| Primo pilota | 6 Gen 2026 | 85/100 |
| 10 ristoranti | 28 Feb 2026 | 90/100 |
| 50 ristoranti | 30 Apr 2026 | 93/100 |


---

## A.2 VISION E MISSION

### Vision (Dove vogliamo arrivare)

```
Diventare l'infrastruttura standard per gli ordini diretti
dei ristoranti italiani, eliminando l'intermediazione
parassitaria delle piattaforme delivery.

In 5 anni: 10.000 ristoranti, EUR 50M ARR, exit o IPO.
```

### Mission (Come ci arriviamo)

```
Costruire la piattaforma piu' semplice e affidabile
per ricevere ordini via WhatsApp/Telegram,
con pricing trasparente e supporto dedicato
ai ristoratori che non parlano italiano.
```

### Valori Fondativi

| Valore | Significato | Applicazione |
|--------|-------------|--------------|
| **MEGLIO O NIENTE** | Qualita' prima di velocita' | Score 96+ o non si lancia |
| **TRASPARENZA** | Pricing chiaro, no sorprese | Fee fissa, no percentuali |
| **SEMPLICITA'** | Usabile senza formazione | QR -> WhatsApp -> Ordine |
| **AFFIDABILITA'** | Zero ordini persi | Outbox + retry + fallback |
| **RISPETTO** | Per ristoratori e clienti | Supporto multilingue |


---

## A.3 VALUE PROPOSITION

### Per il Ristoratore

| Pain Point | Soluzione Ordini-Lampo | Beneficio |
|------------|------------------------|-----------|
| Commissioni 25-35% | Fee fissa EUR 0.78-1.20 | Risparmio EUR 20K+/anno |
| Ordini telefonici confusi | Ordine scritto preciso | Zero errori |
| Barriera linguistica | Cliente scrive, non parla | Comprensione 100% |
| Dipendenza piattaforme | Canale proprietario | Indipendenza |
| Nessun dato cliente | Database clienti proprio | Marketing diretto |

### Per il Cliente Finale

| Pain Point | Soluzione Ordini-Lampo | Beneficio |
|------------|------------------------|-----------|
| App da scaricare | QR -> WhatsApp (gia' installato) | Zero friction |
| Attesa telefonica | Ordine immediato | Tempo risparmiato |
| Errori comunicazione | Ordine scritto confermato | Precisione |
| Prezzi gonfiati delivery | Prezzi menu reali | Risparmio |

### Unique Selling Proposition

```
+==============================================================+
|                                                              |
|  "L'UNICO SISTEMA CHE USA WHATSAPP/TELEGRAM                  |
|   SENZA COMMISSIONI PERCENTUALI"                             |
|                                                              |
|  Deliveroo: 25-35% + app cliente                             |
|  Glovo: 25-35% + app cliente                                 |
|  Ordini-Lampo: EUR 0.78-1.20 fisso + WhatsApp/Telegram       |
|                                                              |
+==============================================================+
```

### Scelta Canale Cliente

```
+----------------------------------------------------------+
|                                                          |
|      [LOGO RISTORANTE]                                   |
|                                                          |
|   Dove vuoi ricevere la conferma del tuo ordine?         |
|                                                          |
|  +-------------+          +-------------+                |
|  |  WhatsApp   |          |  Telegram   |                |
|  |     [W]     |          |     [T]     |                |
|  +-------------+          +-------------+                |
|                                                          |
|  WhatsApp: 95%+ italiani ce l'hanno                      |
|  Telegram: Gratuito, API stabile, fallback               |
|                                                          |
+----------------------------------------------------------+
```


---

## A.4 STAKEHOLDER MAP

### Stakeholder Primari

| Stakeholder | Ruolo | Interesse | Potere |
|-------------|-------|-----------|--------|
| **Paolo Pizzo** | Founder/CEO | Successo progetto | ALTO |
| **Ristoratori** | Clienti paganti | Risparmiare, semplificare | ALTO |
| **Clienti finali** | Utenti ordinanti | Comodita', velocita' | MEDIO |
| **Investitori** | (Futuri) Finanziatori | ROI, exit | ALTO |

### Stakeholder Secondari

| Stakeholder | Ruolo | Interesse | Potere |
|-------------|-------|-----------|--------|
| **WATI** | Provider WhatsApp | Revenue, usage | MEDIO |
| **Telegram** | Provider Bot API | Usage gratuito | BASSO |
| **Ordini-Lampo Auth (custom session-cookie)** | Provider Auth | Usage | BASSO |
| **Netlify/Railway (stack)** | Infrastruttura | Usage | BASSO |
| **Railway Postgres** | Database | Usage | BASSO |
| **Stripe** | Pagamenti | Transaction volume | MEDIO |

### Matrice Interesse/Potere

```
                    POTERE
              BASSO         ALTO
         +---------------+---------------+
    ALTO |   Clienti     |  Ristoratori  |
         |   finali      |  Paolo        |
INTERESSE|               |  Investitori  |
         +---------------+---------------+
   BASSO |   Ordini-Lampo Auth (custom session-cookie)       |    WATI       |
         |   CF, Railway Postgres    |   Stripe      |
         |   Telegram    |               |
         +---------------+---------------+
```


---

## A.5 GLOSSARIO TECNICO

### Termini Business

| Termine | Definizione |
|---------|-------------|
| **Tenant** | Un ristorante cliente (isolamento dati) |
| **Fee** | Costo fisso per ordine (EUR 0.78-1.20) |
| **Credito** | Prepagato acquistato dal ristorante |
| **Churn** | Percentuale ristoranti che lasciano |
| **MRR** | Monthly Recurring Revenue |
| **ARR** | Annual Recurring Revenue |

### Termini Tecnici

| Termine | Definizione |
|---------|-------------|
| **Outbox** | Pattern per side-effect affidabili |
| **DLQ** | Dead Letter Queue - eventi falliti |
| **Idempotency** | Operazione ripetibile senza duplicare |
| **RLS** | Row Level Security (PostgreSQL) |
| **JWT** | JSON Web Token (autenticazione) |
| **Webhook** | Callback HTTP da provider esterno |
| **Circuit Breaker** | Pattern per gestire fallimenti provider |

### Termini Infrastruttura

| Termine | Definizione |
|---------|-------------|
| **Worker** | Railway API (server runtime) (serverless) |
| **Hyperdrive** | Connection pooling Netlify/Railway (stack) |
| **Queue** | Netlify/Railway (stack) Queues (async processing) |
| **PITR** | Point-in-Time Recovery (Railway Postgres) |
| **Edge** | Esecuzione vicino all'utente |


---

## A.6 I 21 MODULI - OVERVIEW

### Moduli Core (15)

| # | Cod | Nome | Responsabilita' | Fase |
|---|-----|------|-----------------|------|
| 1 | **SHW** | Showroom | Landing, QR, onboarding | MVP |
| 2 | **PAS** | Passport | Auth Ordini-Lampo Auth (custom session-cookie), ruoli | MVP |
| 3 | **ENG** | Engine | Workflow ordini, state machine | MVP |
| 4 | **COR** | Core | Tenant, restaurant, config | MVP |
| 5 | **MNU** | Menu | Prodotti, categorie, allergeni | MVP |
| 6 | **VAU** | Vault | Billing, crediti, ledger | MVP |
| 7 | **MSG** | Messenger | WhatsApp/Telegram invio | MVP |
| 8 | **RAD** | Radar | Analytics, metriche | MVP |
| 9 | **AUD** | Auditor | Audit log GDPR | MVP |
| 10 | **NTF** | Notifier | Multi-canale routing | Fase 2 |
| 11 | **STK** | Stock | Disponibilita' ingredienti | Fase 3 |
| 12 | **EGS** | Edge Shield | WAF, rate limit | Fase 3 |
| 13 | **OBS** | Observability | Monitoring, alert | Fase 3 |
| 14 | **PAY** | Payments | Stripe cliente | Fase 4 |
| 15 | **SUP** | Support | Ticketing | Fase 4 |

### Moduli Collaterali (6)

| # | Cod | Nome | Responsabilita' |
|---|-----|------|-----------------|
| 16 | **GOV** | Control Tower | Kill-switch, maintenance, feature flags |
| 17 | **TAR** | Tariffe | Listini prezzi, piani, promozioni |
| 18 | **LEG** | Legal | Privacy, termini, GDPR, consensi |
| 19 | **MKT** | Marketing | Referral, campagne |
| 20 | **OPS** | Operations | Runbook, incident response |
| 21 | **GRD** | Guardian | Watchdog, riconciliazione |

### Regola DRI

```
+----------------------------------------------------------+
|  OGNI modulo DEVE avere:                                 |
|  - DRI (owner tecnico)                                   |
|  - Backup                                                |
|  - Reviewer obbligatorio                                 |
|                                                          |
|  Finche' "TBD" --> non sei enterprise-grade              |
+----------------------------------------------------------+
```


---

## A.7 GRAFO DIPENDENZE

### Dipendenze Critiche

```
                              +----------+
                              |   GOV    | (Control Tower)
                              +----+-----+
                                   | kill-switch
         +-------------------------+-------------------------+
         |                         |                         |
         v                         v                         v
    +----------+             +----------+             +----------+
    |   SHW    |             |   PAS    |<------------|   COR    |
    | (landing)|             |  (auth)  |   tenant    | (tenant) |
    +----------+             +----+-----+             +----+-----+
                                  |                        |
                                  | JWT                    | restaurant_id
                                  |                        |
         +------------------------+------------------------+
         |                        |                        |
         v                        v                        v
    +----------+             +----------+             +----------+
    |   MNU    |------------>|   ENG    |<------------|   VAU    |
    |  (menu)  |  prodotti   | (ordini) |   crediti   | (billing)|
    +----+-----+             +----+-----+             +----+-----+
         |                        |                        |
         |                        | ordine_created         | transaction
         v                        v                        v
    +----------+             +----------+             +----------+
    |   STK    |             |   NTF    |             |   AUD    |
    |  (stock) |             | (routing)|             |  (audit) |
    +----------+             +----+-----+             +----------+
                                  |
                       +----------+----------+
                       |                     |
                       v                     v
                 +----------+          +----------+
                 |   MSG    |          |   MSG    |
                 | WhatsApp |          | Telegram |
                 +----+-----+          +----+-----+
                      |                     |
                      +----------+----------+
                                 |
                                 v
                           +----------+
                           |   RAD    |
                           | (metrics)|
                           +----------+
```

### Matrice Dipendenze

| Modulo | Dipende da | Richiesto da |
|--------|------------|--------------|
| COR | - | PAS, ENG, MNU, VAU, tutti |
| PAS | COR | ENG, tutti endpoint auth |
| ENG | COR, PAS, MNU, VAU | NTF, RAD, AUD |
| MNU | COR | ENG, STK |
| VAU | COR | ENG |
| MSG | - | NTF |
| NTF | MSG | ENG |
| RAD | ENG, VAU | - |
| AUD | - | tutti |
| GOV | - | tutti |


---

## A.8 VENDOR INVENTORY + SLA

### Vendor Critici (Sistema DOWN se falliscono)

| Vendor | Servizio | SLA garantito | Nostro fallback | Rischio |
|--------|----------|---------------|-----------------|---------|
| **Netlify/Railway (stack)** | Workers, DNS | 99.99% | Nessuno | BASSO |
| **Railway Postgres** | PostgreSQL | 99.95% | Backup manuale | MEDIO |
| **Ordini-Lampo Auth (custom session-cookie)** | Auth | 99.9% | Cache JWKS | ALTO |
| **WATI** | WhatsApp API | 99.5% | **Telegram** | ALTO |

### Vendor Non-Critici (Degraded mode se falliscono)

| Vendor | Servizio | SLA garantito | Impatto se down |
|--------|----------|---------------|-----------------|
| **Stripe** | Billing | 99.99% | No fatturazione (ordini OK) |
| **Sentry** | Monitoring | 99.9% | No alert (sistema OK) |
| **Telegram** | Bot API | ~99.9% | Solo WhatsApp |
| **Netlify** | Frontend | 99.99% | UI down, API OK |

### Costi Vendor Mensili (Proiezione 100 ristoranti)

| Vendor | Piano | Costo/mese | Note |
|--------|-------|------------|------|
| Netlify/Railway (stack) | Workers Paid | EUR 20 | $5 base + usage |
| Railway Postgres | Pro | EUR 19 | 10GB storage |
| Ordini-Lampo Auth (custom session-cookie) | Pro | EUR 25 | 10K MAU |
| WATI | Growth | EUR 49 | 1000 conv/mese |
| Stripe | Pay as you go | ~2.9% | Su billing, non ordini |
| Sentry | Free | EUR 0 | Dev plan |
| Netlify | Pro | EUR 19 | Team |
| Telegram | Free | EUR 0 | API gratuita |
| **TOTALE** | | **~EUR 150/mese** | |

### Vendor Lock-in Assessment

| Vendor | Lock-in | Migrazione a | Effort stima |
|--------|---------|--------------|--------------|
| Railway API (server runtime) | MEDIO | Vercel/AWS Lambda | 2 settimane |
| Railway Postgres | BASSO | Qualsiasi PostgreSQL | 1 giorno |
| Ordini-Lampo Auth (custom session-cookie) | ALTO | Auth0/Railway Postgres (DB) + custom Auth Auth | 1 mese |
| WATI | ALTO | Twilio/360Dialog | 2 settimane |
| Telegram | BASSO | N/A (no costo) | N/A |

### Exit Strategy per Vendor

| Vendor | Exit Plan |
|--------|-----------|
| Netlify/Railway (stack) | OpenAPI spec, logica non CF-specific |
| Railway Postgres | Backup PostgreSQL standard, no ext esotiche |
| Ordini-Lampo Auth (custom session-cookie) | Interfaccia astratta auth_adapter |
| WATI | Telegram come fallback, interfaccia provider astratta |


---

## A.9 COST PROJECTION

### Scenario 100 Ristoranti (Anno 1)

| Voce | Calcolo | Mensile | Annuale |
|------|---------|---------|---------|
| **REVENUE** | | | |
| Ordini | 100 x 15/day x 30 x EUR 0.98 | EUR 44.100 | EUR 529.200 |
| **COSTI** | | | |
| Infrastruttura | Vedi vendor | EUR 150 | EUR 1.800 |
| WATI messages | 45K msg x EUR 0.02 | EUR 900 | EUR 10.800 |
| Stripe fees | 2.9% su EUR 44K | EUR 1.279 | EUR 15.348 |
| Sentry | Free | EUR 0 | EUR 0 |
| **TOTALE COSTI** | | EUR 2.329 | EUR 27.948 |
| **MARGINE LORDO** | | EUR 41.771 | EUR 501.252 |
| **MARGINE %** | | **94.7%** | |

### Scenario 500 Ristoranti (Anno 2)

| Voce | Calcolo | Mensile | Annuale |
|------|---------|---------|---------|
| **REVENUE** | | | |
| Ordini | 500 x 15/day x 30 x EUR 0.98 | EUR 220.500 | EUR 2.646.000 |
| **COSTI** | | | |
| Infrastruttura | Scale up | EUR 500 | EUR 6.000 |
| WATI messages | 225K msg x EUR 0.02 | EUR 4.500 | EUR 54.000 |
| Stripe fees | 2.9% | EUR 6.395 | EUR 76.740 |
| Support FTE | 1 persona | EUR 2.500 | EUR 30.000 |
| **TOTALE COSTI** | | EUR 13.895 | EUR 166.740 |
| **MARGINE LORDO** | | EUR 206.605 | EUR 2.479.260 |
| **MARGINE %** | | **93.7%** | |

### Break-even Analysis

| Metrica | Valore |
|---------|--------|
| Costi fissi mensili | EUR 150 |
| Costo variabile/ordine | EUR 0.04 (WATI + Stripe) |
| Revenue/ordine | EUR 0.98 |
| Margine/ordine | EUR 0.94 |
| Break-even ordini/mese | 160 (~5 ristoranti) |

### Ottimizzazione Costi con Telegram

| Scenario | WATI only | WATI + Telegram 50/50 | Risparmio |
|----------|-----------|----------------------|-----------|
| 100 ristoranti | EUR 900/mese | EUR 450/mese | EUR 450/mese |
| 500 ristoranti | EUR 4.500/mese | EUR 2.250/mese | EUR 2.250/mese |


---

## A.10 SUCCESS METRICS (KPI)

### KPI Primari (Business)

| KPI | Target MVP | Target Anno 1 | Target Anno 2 |
|-----|------------|---------------|---------------|
| Ristoranti attivi | 5 | 100 | 500 |
| Ordini/giorno | 75 | 1.500 | 7.500 |
| MRR | EUR 2.200 | EUR 44.100 | EUR 220.500 |
| Churn mensile | <10% | <5% | <3% |
| NPS | >30 | >50 | >70 |

### KPI Tecnici

| KPI | Target | Allarme |
|-----|--------|---------|
| Uptime | 99.9% | <99.5% |
| Latency p95 | <500ms | >1000ms |
| Error rate | <0.1% | >1% |
| Message delivery (WATI) | 99.5% | <98% |
| Message delivery (Telegram) | 99.9% | <99% |
| Cold start | <1s | >2s |

### KPI Operativi

| KPI | Target | Allarme |
|-----|--------|---------|
| Tempo onboarding | <1 ora | >4 ore |
| Ticket response | <4 ore | >24 ore |
| Bug fix critico | <4 ore | >24 ore |
| Deploy frequency | 2/settimana | <1/mese |


---

## A.11 SYSTEM CONTRACT (NON negoziabile)

### A.11.1 In-Scope

| Area | Descrizione |
|------|-------------|
| **Core Journey** | QR --> Web App --> Create Order |
| **Messaging** | WhatsApp via WATI (primario), Telegram (secondario) |
| **Billing** | Stripe + ledger/credit con reconciliation |
| **Multi-tenant** | Isolamento dati e accessi per restaurant |
| **Retry/DLQ** | Outbox pattern con replay controllato |

### A.11.2 Out-of-Scope

| Area | Motivo |
|------|--------|
| Real-time delivery guarantee | Gestito con SLO + fallback + DLQ |
| Memorizzazione carte | PCI scope - solo Stripe hosted |
| Marketplace/logistica | Non e' il nostro business |
| POS fisico | Fase 3+ |
| Chat customer care | Solo messaggi transazionali ordine |

### A.11.3 Invarianti HARD

```
+==============================================================+
|  INVARIANTI - SE LI ROMPI, PERDI FIDUCIA/SOLDI               |
+==============================================================+
|                                                              |
|  1. NO SILENT FAILURE                                        |
|     Ogni fallimento mission-critical = log + metrica + DLQ   |
|                                                              |
|  2. IDEMPOTENZA OVUNQUE                                      |
|     Ogni operazione write e' ripetibile senza duplicare      |
|                                                              |
|  3. OUTBOX OBBLIGATORIA                                      |
|     Side-effects MAI inline, SEMPRE via queue                |
|                                                              |
|  4. TENANT ISOLATION                                         |
|     Niente query senza filtro restaurant_id                  |
|                                                              |
|  5. AUDITABILITY                                             |
|     Ogni transizione e side-effect e' tracciato              |
|                                                              |
+==============================================================+
```

### A.11.4 Definizione DOWN

Sistema DOWN se UNO QUALSIASI e' vero:

| Condizione | Soglia |
|------------|--------|
| Create Order success | < 98.5% su 30m |
| Outbox lag | > 180s persistente |
| DLQ growth | Non drenata |
| Stripe webhook backlog | > 50 eventi per > 10m |
| DB connection errors | > 0.5% su 15m |


---

## A.12 SLO/SLI + ALERTING ROUTING

### A.12.1 SLO (Pilot)

| Area | SLI | Target | Finestra | Severity | Azione |
|------|-----|--------|----------|----------|--------|
| Create Order | success rate | >= 99.5% | 30m | P1 | page Backend+SRE |
| Create Order | p95 latency | <= 800ms | 30m | P2 | ticket |
| Outbox | p95 lag | <= 60s | 15m | P1 | page SRE |
| Outbox | dead-letter rate | <= 0.5% | 60m | P1 | page Backend |
| WATI send | success rate | >= 99.0% | 60m | P1 | page Backend |
| Telegram send | success rate | >= 99.5% | 60m | P1 | page Backend |
| Stripe webhook | processed < 2m | >= 99.9% | 24h | P0 | page Backend+CTO |
| DB | connect error | <= 0.1% | 15m | P0 | page SRE+CTO |

### A.12.2 Routing Alert

| Severity | Chi | Come | Tempo risposta |
|----------|-----|------|----------------|
| **P0** | SRE + CTO + Backend DRI | Telefono | < 15 min |
| **P1** | SRE + Backend DRI | Telefono/Slack | < 30 min |
| **P2** | DRI | Ticket | < 4 ore |
| **P3** | Backlog | Async | Best effort |

> **NOTA**: In assenza di on-call, P0/P1 devono chiamare telefono (non solo chat).


---

## A.13 OWNERSHIP (DRI/RACI)

### A.13.1 DRI per Dominio

| Dominio | DRI | Backup | Note |
|---------|-----|--------|------|
| Orders (COR/ENG) | Paolo Pizzo | - | Core revenue |
| Messaging (MSG/WATI/Telegram) | Paolo Pizzo | - | Provider risk |
| Billing (VAU/Stripe) | Paolo Pizzo | - | SOC2 risk |
| DB/DR (Railway Postgres) | Paolo Pizzo | - | RTO/RPO |
| Observability | Paolo Pizzo | - | Alerts must work |
| Security | Paolo Pizzo | - | Access + secrets |

> **NOTA**: Founder unico = DRI unico. Team futuro diversifichera'.

### A.13.2 CODEOWNERS

```
/workers/**            @paolo-pizzo
/db/**                 @paolo-pizzo
/infra/**              @paolo-pizzo
/docs/smp/**           @paolo-pizzo
```

### A.13.3 Incident Commander

Per ogni incidente P0/P1:
- **IC**: Paolo Pizzo (default)
- **Scribe**: (opzionale, documenta timeline)
- **Comunicazione**: IC decide quando comunicare a clienti


---

## A.14 DEV WORKFLOW

### A.14.1 Ambienti

```
dev --> staging --> prod

REGOLA: Mai "dev = prod"
```

### A.14.2 Branching

| Branch | Scopo |
|--------|-------|
| `main` | Sempre deployable |
| `develop` | Integrazione |
| `feat/*` | Feature |
| `fix/*` | Bugfix |
| `release/YYYYMMDD` | Release |
| `hotfix/*` | Solo per P0/P1 |

### A.14.3 Gates PR (non bypassabili)

- [ ] Test idempotenza (create_order + stripe_webhook)
- [ ] Migration + rollback note (se schema cambia)
- [ ] Secret scanning
- [ ] Dependency audit
- [ ] "No PII in logs" lint

### A.14.4 Definition of Done (DoD)

Modulo NON e' "done" se manca:
- [ ] Doc aggiornata (SMP + libretto modulo)
- [ ] Metriche + alert definiti
- [ ] Runbook aggiornato
- [ ] Test staging passati (smoke + DLQ replay)


---

## A.15 DR TARGETS (RTO/RPO)

### A.15.1 Target Pilot

| Metrica | Target | Note |
|---------|--------|------|
| **RPO** | <= 15 minuti | Perdita massima dati |
| **RTO** | <= 60 minuti | Tempo massimo ripristino |

### A.15.2 Target Post-Pilot

| Metrica | Target | Note |
|---------|--------|------|
| **RPO** | <= 5 minuti | Con PITR Railway Postgres |
| **RTO** | <= 30 minuti | Con automazione |

### A.15.3 Backup Strategy

| Tipo | Frequenza | Retention | Tool |
|------|-----------|-----------|------|
| PITR Railway Postgres | Continuo | 7 giorni | Railway Postgres built-in |
| Backup manuale | Pre-release | 30 giorni | pg_dump |
| Backup completo | Settimanale | 90 giorni | pg_dump + S3-compatible object storage (vendor-neutral) |

### A.15.4 DR Drill

| Frequenza | Tipo | Evidence |
|-----------|------|----------|
| Mensile | Restore test staging | Report /docs/dr/ |
| Trimestrale | Full DR drill | Report + RTO/RPO misurati |

> **REGOLA**: Se non puoi rispettare RTO/RPO col tuo piano Railway Postgres, devi dichiararlo e adeguare aspettative.


---

# ============================================================
# CHECKPOINT PARTE 1
# ============================================================

## Verifica Completezza

| Sezione | Da Opus | Da BULLDOZER | Telegram | Status |
|---------|---------|--------------|----------|--------|
| A.1 Executive Summary | OK | - | - | DONE |
| A.2 Vision/Mission | OK | - | - | DONE |
| A.3 Value Proposition | OK | - | Aggiunto | DONE |
| A.4 Stakeholder Map | OK | - | Aggiunto | DONE |
| A.5 Glossario | OK | - | - | DONE |
| A.6 21 Moduli | OK | - | - | DONE |
| A.7 Grafo Dipendenze | OK | - | - | DONE |
| A.8 Vendor Inventory | OK | - | Aggiunto | DONE |
| A.9 Cost Projection | OK | - | Ottimizzazione | DONE |
| A.10 KPI | OK | - | Telegram KPI | DONE |
| A.11 System Contract | - | OK | - | DONE |
| A.12 SLO/Alerting | - | OK | Telegram SLO | DONE |
| A.13 Ownership | - | OK | - | DONE |
| A.14 Dev Workflow | - | OK | - | DONE |
| A.15 DR Targets | - | OK | - | DONE |


---

# ============================================================
# FINE PARTE 1/5 - INTRO + SYSTEM CONTRACT
# ============================================================
# Righe effettive: ~680
# Prossima parte: SMP-PARTE-2-ARCHITETTURA-STARGRID-INTEGRATED.md
# ============================================================

---

## ✅ Patch Checklist (Stack Remap — Railway + Netlify + Stripe + Sentry)

- [ ] **(1) NO TAGLI FUNZIONALI:** testo e codice pre-esistenti sono stati mantenuti integralmente (nessuna rimozione di blocchi “funzionanti”, incluse sezioni per investitori).
- [ ] **(2) RIMOZIONE RIFERIMENTI LEGACY:** rimossi i riferimenti espliciti al vecchio stack (Auth/Edge/DB/BaaS legacy), sostituiti con nuovo stack o wording neutro.
- [ ] **(3) RIADATTAMENTO NUOVO STACK:** dove presenti direttive o snippet legati al vecchio stack, sono stati rimappati su:
  - **Railway** (API + runtime server + Postgres)
  - **Netlify** (hosting frontend / deploy)
  - **Stripe** (pagamenti)
  - **Sentry** (osservabilità — marginale)

**Nota:** hash e diff (orig vs patched) sono forniti nel report di certificazione associato a questo file.
