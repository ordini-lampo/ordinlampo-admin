# ============================================================
# STARGRID MASTER PROJECT (SMP) - PARTE 4/5
# ============================================================
# SEZIONE D: GUARDRAIL
# ============================================================
# Codice: SMP-V7.0-INTEGRATED
# Data: 24 Dicembre 2025
# Target righe questa sezione: ~600
# ============================================================


---

# INDICE PARTE 4 - GUARDRAIL

```
+==============================================================+
|            SMP PARTE 4/5 - SEZIONE D: GUARDRAIL              |
+==============================================================+
|                                                              |
|  D.1   DO NOT List (Regole Hard)                             |
|  D.2   Alerting Contract                                     |
|  D.3   Metriche Obbligatorie                                 |
|  D.4   Dashboard Panels                                      |
|  D.5   CI/CD Gates                                           |
|  D.6   Rate Limit Runtime                                    |
|  D.7   Circuit Breaker Config                                |
|  D.8   Security Baseline                                     |
|  D.9   Incident Classification                               |
|  D.10  Kill-Switch Procedures                                |
|  D.11  Change Management                                     |
|  D.12  Audit Requirements                                    |
|                                                              |
+==============================================================+
```


---

## D.1 DO NOT LIST (Regole Hard)

### Le 10 Regole NON Negoziabili

```
+==============================================================+
|                    DO NOT - MAI VIOLARE                      |
+==============================================================+

1. MAI chiamare provider (WATI/Telegram/Stripe) in transazione DB
   --> Solo via Outbox, side-effects sempre async

2. MAI loggare PII raw (telefono, email, nome)
   --> Hash o redact SEMPRE

3. MAI query cross-tenant senza restaurant_id
   --> RLS enforced, SET app.restaurant_id obbligatorio

4. MAI UPDATE o DELETE su audit_log o billing_ledger
   --> Append-only, RULE PostgreSQL blocca

5. MAI deploy in prod senza checklist completa
   --> Gate CI obbligatorio

6. MAI secrets in codice, log, o env files
   --> Solo Netlify/Railway (stack) Secrets

7. MAI trust client per importi billing
   --> Solo webhook Stripe e' source of truth

8. MAI skip signature verification webhooks
   --> Stripe, WATI, Telegram SEMPRE verificati

9. MAI retry infinito
   --> Max 8 tentativi, poi DLQ

10. MAI ignorare errori silenziosamente
    --> Log + metrica + alert per ogni failure

+==============================================================+
```

### Enforcement

| Regola | Come Enforced | Test |
|--------|---------------|------|
| 1. No sync calls | Code review + linting | Unit test mock |
| 2. No PII logs | Log scanner CI | grep pattern |
| 3. RLS | PostgreSQL policy | Integration test |
| 4. Append-only | PostgreSQL RULE | Attempt UPDATE/DELETE |
| 5. Deploy gate | GitHub Actions | CI failure |
| 6. Secrets | Secret scanning | gitleaks |
| 7. Client trust | No amount in API | Code review |
| 8. Signature | Middleware | Request without sig |
| 9. Max retry | Config check | Unit test |
| 10. Error handling | Code coverage | Test error paths |


---

## D.2 ALERTING CONTRACT

### SLO/SLI Summary

| Area | SLI | Target | Window | Severity |
|------|-----|--------|--------|----------|
| Create Order | success rate | >= 99.5% | 30m | P1 |
| Create Order | p95 latency | <= 800ms | 30m | P2 |
| Outbox | lag p95 | <= 60s | 15m | P1 |
| Outbox | DLQ rate | <= 0.5% | 60m | P1 |
| WATI | success rate | >= 99.0% | 60m | P1 |
| Telegram | success rate | >= 99.5% | 60m | P1 |
| Stripe webhook | processed < 2m | >= 99.9% | 24h | P0 |
| DB | connection error | <= 0.1% | 15m | P0 |

### Routing per Severity

```
+----------------------------------------------------------+
|  P0 - CRITICAL (Revenue/Data loss imminente)             |
|  - Page: SRE + CTO + Backend DRI                         |
|  - Response: < 15 minuti                                 |
|  - Channel: Telefono + Slack #incidents                  |
|  - Escalation: Ogni 15 min se non ack                    |
+----------------------------------------------------------+
|  P1 - HIGH (Degraded service, customer impact)           |
|  - Page: SRE + Backend DRI                               |
|  - Response: < 30 minuti                                 |
|  - Channel: Slack #incidents + PagerDuty                 |
|  - Escalation: Ogni 30 min se non ack                    |
+----------------------------------------------------------+
|  P2 - MEDIUM (Performance degradation)                   |
|  - Ticket: Backend DRI                                   |
|  - Response: < 4 ore                                     |
|  - Channel: Slack #alerts                                |
+----------------------------------------------------------+
|  P3 - LOW (Tech debt, non-urgent)                        |
|  - Backlog: Next sprint                                  |
|  - Response: Best effort                                 |
|  - Channel: GitHub Issues                                |
+----------------------------------------------------------+
```

### Alert Definitions

```yaml
# ============================================================
# Alert Definitions (Prometheus/Grafana format)
# ============================================================

# P0: Database connection errors
- alert: DatabaseConnectionErrors
  expr: |
    sum(rate(db_connect_errors_total[15m])) 
    / sum(rate(db_queries_total[15m])) > 0.001
  for: 5m
  labels:
    severity: P0
  annotations:
    summary: "Database connection error rate > 0.1%"
    runbook: "https://docs.ordini-lampo.it/runbooks/db-connection"

# P0: Stripe webhook backlog
- alert: StripeWebhookBacklog
  expr: |
    count(stripe_events{status=~"received|processing"}) > 50
  for: 10m
  labels:
    severity: P0
  annotations:
    summary: "Stripe webhook backlog > 50 events for 10m"
    runbook: "https://docs.ordini-lampo.it/runbooks/stripe-backlog"

# P1: Create Order SLO breach
- alert: CreateOrderSLOBreach
  expr: |
    sum(rate(api_create_order_total{status="success"}[30m])) 
    / sum(rate(api_create_order_total[30m])) < 0.995
  for: 5m
  labels:
    severity: P1
  annotations:
    summary: "Create Order success rate < 99.5%"
    runbook: "https://docs.ordini-lampo.it/runbooks/create-order"

# P1: Outbox lag
- alert: OutboxLagHigh
  expr: |
    histogram_quantile(0.95, 
      rate(outbox_processing_duration_seconds_bucket[15m])
    ) > 60
  for: 5m
  labels:
    severity: P1
  annotations:
    summary: "Outbox p95 lag > 60 seconds"
    runbook: "https://docs.ordini-lampo.it/runbooks/outbox-lag"

# P1: DLQ growing
- alert: DLQGrowing
  expr: |
    sum(rate(outbox_dead_total[60m])) 
    / sum(rate(outbox_events_total[60m])) > 0.005
  for: 10m
  labels:
    severity: P1
  annotations:
    summary: "DLQ rate > 0.5%"
    runbook: "https://docs.ordini-lampo.it/runbooks/dlq"

# P1: WATI failures
- alert: WATIFailureRate
  expr: |
    sum(rate(wati_send_total{status="failed"}[60m])) 
    / sum(rate(wati_send_total[60m])) > 0.01
  for: 10m
  labels:
    severity: P1
  annotations:
    summary: "WATI failure rate > 1%"
    runbook: "https://docs.ordini-lampo.it/runbooks/wati"

# P1: Telegram failures
- alert: TelegramFailureRate
  expr: |
    sum(rate(telegram_send_total{status="failed"}[60m])) 
    / sum(rate(telegram_send_total[60m])) > 0.005
  for: 10m
  labels:
    severity: P1
  annotations:
    summary: "Telegram failure rate > 0.5%"
    runbook: "https://docs.ordini-lampo.it/runbooks/telegram"

# P2: Latency degradation
- alert: CreateOrderLatencyHigh
  expr: |
    histogram_quantile(0.95, 
      rate(api_create_order_duration_seconds_bucket[30m])
    ) > 1.2
  for: 15m
  labels:
    severity: P2
  annotations:
    summary: "Create Order p95 latency > 1200ms"

# P2: Rate limiting triggered
- alert: RateLimitTriggered
  expr: |
    sum(rate(rate_limit_exceeded_total[60m])) > 100
  for: 30m
  labels:
    severity: P2
  annotations:
    summary: "Rate limiting triggered > 100/hour"
```


---

## D.3 METRICHE OBBLIGATORIE

### Metriche Core

```typescript
// ============================================================
// Metriche MUST-HAVE
// ============================================================

// API Metrics
api_create_order_total{status="success|error", restaurant_id}
api_create_order_duration_seconds{quantile="0.5|0.95|0.99"}
api_requests_total{method, path, status_code}

// Outbox Metrics
outbox_events_total{event_type, status}
outbox_pending_count
outbox_retry_count
outbox_dead_count
outbox_oldest_pending_seconds
outbox_processing_duration_seconds

// Provider Metrics
wati_send_total{status="success|failed|rate_limited"}
wati_delivery_total{status="sent|delivered|read|failed"}
wati_latency_seconds
telegram_send_total{status="success|failed|rate_limited"}
telegram_delivery_total{status}
telegram_latency_seconds

// Stripe Metrics
stripe_webhook_received_total{type}
stripe_webhook_processed_total{type, status}
stripe_webhook_latency_seconds
stripe_webhook_backlog_count

// Database Metrics
db_queries_total{query_type}
db_query_duration_seconds{quantile}
db_connect_errors_total
db_pool_size
db_pool_available

// Business Metrics
orders_total{restaurant_id, status}
orders_revenue_cents{restaurant_id}
restaurants_active_count
messages_sent_total{provider, restaurant_id}
```

### Metriche di Alerting Specifiche

```sql
-- ============================================================
-- Query per metriche (eseguire periodicamente)
-- ============================================================

-- Outbox pending count
SELECT COUNT(*) as outbox_pending_count 
FROM outbox_events 
WHERE status IN ('pending', 'retry');

-- Outbox oldest pending
SELECT EXTRACT(EPOCH FROM (now() - MIN(created_at))) as outbox_oldest_pending_seconds
FROM outbox_events 
WHERE status IN ('pending', 'retry');

-- DLQ count
SELECT COUNT(*) as outbox_dead_count 
FROM outbox_events 
WHERE status = 'dead';

-- Stripe backlog
SELECT COUNT(*) as stripe_webhook_backlog
FROM stripe_events 
WHERE status IN ('received', 'processing')
AND received_at < now() - interval '2 minutes';

-- Orders last hour
SELECT COUNT(*) as orders_last_hour
FROM orders 
WHERE created_at > now() - interval '1 hour';

-- Message success rate (last hour)
SELECT 
  provider,
  COUNT(*) FILTER (WHERE status IN ('sent', 'delivered', 'read')) as success,
  COUNT(*) as total,
  ROUND(100.0 * COUNT(*) FILTER (WHERE status IN ('sent', 'delivered', 'read')) / NULLIF(COUNT(*), 0), 2) as success_rate
FROM provider_messages
WHERE created_at > now() - interval '1 hour'
GROUP BY provider;
```


---

## D.4 DASHBOARD PANELS

### Panel 1: Orders Overview

```
+------------------------------------------------------------------+
|                      ORDERS DASHBOARD                             |
+------------------------------------------------------------------+
|  [Orders/Hour]     [Success Rate]     [Avg Latency]              |
|      156              99.7%              342ms                    |
|                                                                  |
|  [Orders by Status - Last 24h]                                   |
|  ████████████████████ completed (89%)                            |
|  ████ confirmed (5%)                                             |
|  ██ preparing (3%)                                               |
|  █ cancelled (3%)                                                |
|                                                                  |
|  [Orders Timeline - Last 7 days]                                 |
|  Mon  Tue  Wed  Thu  Fri  Sat  Sun                               |
|   │    │    │    │    │    │    │                                |
|  ─┼────┼────┼────┼────┼────┼────┼─                               |
+------------------------------------------------------------------+
```

### Panel 2: Async Processing

```
+------------------------------------------------------------------+
|                   ASYNC PROCESSING DASHBOARD                      |
+------------------------------------------------------------------+
|  [Outbox Pending]   [Outbox DLQ]    [Oldest Pending]             |
|       12                 0              23 sec                    |
|                                                                  |
|  [Processing Lag P95]                                            |
|  ████████░░░░░░░░░░░░ 34s (target: 60s)                          |
|                                                                  |
|  [Events by Type - Last Hour]                                    |
|  msg.wati.send       ████████████████ 156                        |
|  msg.telegram.send   ████████ 89                                 |
|  billing.webhook     ████ 45                                     |
|                                                                  |
|  [DLQ Events - Last 24h]                                         |
|  (empty - all clear)                                             |
+------------------------------------------------------------------+
```

### Panel 3: Provider Health

```
+------------------------------------------------------------------+
|                   PROVIDER HEALTH DASHBOARD                       |
+------------------------------------------------------------------+
|           WATI                          TELEGRAM                  |
|  [Status: HEALTHY]              [Status: HEALTHY]                |
|  Success: 99.2%                 Success: 99.8%                   |
|  Latency: 1.2s                  Latency: 0.4s                    |
|  Circuit: CLOSED                Circuit: CLOSED                  |
|                                                                  |
|  [WATI Delivery Status]         [Telegram Delivery Status]       |
|  sent      ████████ 45%         sent      ████████████ 60%       |
|  delivered ██████████ 50%       delivered ████████ 40%           |
|  read      █████ 25%                                             |
|  failed    ░ 1%                 failed    ░ 0.2%                 |
|                                                                  |
|           STRIPE                                                 |
|  [Status: HEALTHY]                                               |
|  Webhook Backlog: 0                                              |
|  Processing Rate: 100%                                           |
+------------------------------------------------------------------+
```


---

## D.5 CI/CD GATES

### GitHub Actions Workflow

```yaml
# ============================================================
# .github/workflows/ci.yml
# ============================================================

name: CI Pipeline

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  lint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
      - run: npm ci
      - run: npm run lint
      - run: npm run typecheck

  security:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      # Secret scanning
      - name: Gitleaks
        uses: gitleaks/gitleaks-action@v2
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
      
      # Dependency audit
      - name: Audit
        run: npm audit --audit-level=high
      
      # No PII in logs
      - name: Check PII in logs
        run: |
          ! grep -r "customer_phone\|customer_email" src/ --include="*.ts" | \
            grep -v "hash_phone\|hashPhone\|redact" | \
            grep "console.log\|logger"

  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
      - run: npm ci
      
      # Unit tests
      - name: Unit Tests
        run: npm run test:unit
      
      # Idempotency tests (required)
      - name: Idempotency Tests
        run: npm run test:idempotency
      
      # Webhook signature tests (required)
      - name: Webhook Tests
        run: npm run test:webhooks

  migration-check:
    runs-on: ubuntu-latest
    if: contains(github.event.pull_request.labels.*.name, 'has-migration')
    steps:
      - uses: actions/checkout@v4
      
      # Check migration has rollback
      - name: Check Rollback Notes
        run: |
          for f in db/migrations/*.sql; do
            if ! grep -q "ROLLBACK:" "$f"; then
              echo "ERROR: Migration $f missing ROLLBACK notes"
              exit 1
            fi
          done

  deploy-staging:
    needs: [lint, security, test]
    if: github.ref == 'refs/heads/develop'
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: cloudflare/wrangler-action@v3
        with:
          apiToken: ${{ secrets.CF_API_TOKEN }}
          command: deploy --env staging

  deploy-production:
    needs: [lint, security, test]
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    environment: production
    steps:
      - uses: actions/checkout@v4
      
      # Pre-deploy checklist
      - name: Verify Checklist
        run: |
          echo "Checking deployment readiness..."
          # Add automated checks here
      
      - uses: cloudflare/wrangler-action@v3
        with:
          apiToken: ${{ secrets.CF_API_TOKEN }}
          command: deploy --env production
      
      # Post-deploy health check
      - name: Health Check
        run: |
          sleep 30
          curl -f https://api.ordini-lampo.it/health/ready || exit 1
```


---

## D.6 RATE LIMIT RUNTIME

### Configuration

| Endpoint | Limit | Window | Identifier |
|----------|-------|--------|------------|
| POST /v1/orders | 60/min | 60s | restaurant_id or IP |
| GET /v1/orders | 120/min | 60s | restaurant_id or IP |
| GET /v1/admin/* | 300/min | 60s | user_id |
| POST /webhooks/* | 1000/min | 60s | global |

### Provider Limits

| Provider | Limit | Burst | Notes |
|----------|-------|-------|-------|
| WATI | 30/min per restaurant | 10 | Official limit |
| WATI Global | 600/min | 100 | Account limit |
| Telegram | 1/sec per chat | N/A | Official limit |
| Telegram Global | 30/sec | N/A | Official limit |

### Implementation

```typescript
// Rate limit check middleware
const LIMITS = {
  'create_order': { window: 60, max: 60 },
  'read_orders': { window: 60, max: 120 },
  'admin': { window: 60, max: 300 },
  'webhooks': { window: 60, max: 1000 },
  'wati_per_restaurant': { window: 60, max: 30 },
  'wati_global': { window: 60, max: 600 },
  'telegram_per_chat': { window: 1, max: 1 },
  'telegram_global': { window: 1, max: 30 },
};
```


---

## D.7 CIRCUIT BREAKER CONFIG

### Configuration

| Service | Failure Threshold | Success Threshold | Timeout |
|---------|-------------------|-------------------|---------|
| WATI | 5 failures | 2 successes | 2 min |
| Telegram | 5 failures | 2 successes | 1 min |
| Stripe | 3 failures | 2 successes | 5 min |
| Railway Postgres (via Hyperdrive) | N/A | N/A | Handled by Hyperdrive |

### State Transitions

```
CLOSED ──(failures >= threshold)──> OPEN
   ^                                   │
   │                                   │
   │                              (timeout)
   │                                   │
   │                                   v
   └──(successes >= threshold)── HALF_OPEN
```

### Metrics

```typescript
// Circuit breaker metrics
circuit_breaker_state{service="wati"} // 0=closed, 1=open, 2=half_open
circuit_breaker_failures{service}
circuit_breaker_successes{service}
circuit_breaker_state_changes_total{service, from, to}
```


---

## D.8 SECURITY BASELINE

### Secrets Management

| Secret | Where | Rotation | Access |
|--------|-------|----------|--------|
| DATABASE_URL | CF Secrets | 90 days | Workers only |
| CLERK_SECRET_KEY | CF Secrets | 90 days | Workers only |
| WATI_API_KEY | CF Secrets | 90 days | Workers only |
| TELEGRAM_BOT_TOKEN | CF Secrets | On breach | Workers only |
| STRIPE_SECRET_KEY | CF Secrets | 90 days | Workers only |
| STRIPE_WEBHOOK_SECRET | CF Secrets | 90 days | Workers only |

### Access Control

```
+----------------------------------------------------------+
|  Principle of Least Privilege                            |
+----------------------------------------------------------+
|  - 2FA obbligatoria per tutti gli account                |
|  - Accesso DB solo via Hyperdrive (no direct)            |
|  - Secrets accessibili solo dai Workers                  |
|  - GitHub branch protection su main                      |
|  - Review obbligatoria per PR                            |
+----------------------------------------------------------+
```

### PII Handling

| Data | Storage | Encryption | Retention |
|------|---------|------------|-----------|
| customer_phone | Hashed | SHA256 | 2 years |
| customer_name | Plain | At-rest | 2 years |
| email (users) | Plain | At-rest | Account lifetime + 30 days |
| IP address | audit_log | At-rest | 90 days |


---

## D.9 INCIDENT CLASSIFICATION

### Severity Matrix

| Severity | Criteria | Examples |
|----------|----------|----------|
| **P0** | Revenue loss, data leak, orders blocked | DB down, Stripe broken, security breach |
| **P1** | Degraded service, partial outage | WATI down (Telegram OK), high latency |
| **P2** | Bug with workaround | UI glitch, wrong calculation |
| **P3** | Tech debt, improvement | Performance optimization |

### Response Times

| Severity | Acknowledge | Resolve | Postmortem |
|----------|-------------|---------|------------|
| P0 | 15 min | 2 hours | 24 hours |
| P1 | 30 min | 4 hours | 48 hours |
| P2 | 4 hours | 24 hours | Optional |
| P3 | Best effort | Sprint | N/A |

### Escalation Path

```
P0: Paolo (founder) --> immediato
P1: Paolo --> entro 30 min
P2: Ticket GitHub --> next business day
P3: Backlog --> next sprint
```


---

## D.10 KILL-SWITCH PROCEDURES

### Global Maintenance Mode

```sql
-- ATTIVARE maintenance mode (blocca nuovi ordini)
UPDATE gov_config 
SET value = 'true', 
    updated_at = now(), 
    updated_by = 'paolo@ordini-lampo.it'
WHERE key = 'maintenance_mode';

-- DISATTIVARE maintenance mode
UPDATE gov_config 
SET value = 'false', 
    updated_at = now(), 
    updated_by = 'paolo@ordini-lampo.it'
WHERE key = 'maintenance_mode';
```

### Disable Specific Provider

```sql
-- Disabilita WATI (Telegram fallback attivo)
UPDATE gov_config SET value = 'false' WHERE key = 'wati_enabled';

-- Disabilita Telegram (solo WATI)
UPDATE gov_config SET value = 'false' WHERE key = 'telegram_enabled';

-- Disabilita entrambi (NO messaging)
UPDATE gov_config SET value = 'false' WHERE key = 'wati_enabled';
UPDATE gov_config SET value = 'false' WHERE key = 'telegram_enabled';
```

### Suspend Single Restaurant

```sql
-- Sospendi ristorante (es. disputa, frode)
UPDATE billing_state 
SET status = 'suspended', updated_at = now()
WHERE restaurant_id = '<UUID>';

-- Riattiva
UPDATE billing_state 
SET status = 'active', updated_at = now()
WHERE restaurant_id = '<UUID>';
```

### Emergency Rate Limit

```sql
-- Riduci rate limit globale in emergenza
UPDATE gov_config 
SET value = '10' 
WHERE key = 'max_orders_per_minute';

-- Ripristina
UPDATE gov_config 
SET value = '100' 
WHERE key = 'max_orders_per_minute';
```


---

## D.11 CHANGE MANAGEMENT

### Normal Change

```
1. PR creata con descrizione
2. CI passa (lint, security, test)
3. Review approvata
4. Merge su develop
5. Deploy automatico su staging
6. Test manuale su staging
7. Merge su main
8. Deploy production (con approval)
9. Health check post-deploy
```

### Emergency Change (P0/P1)

```
1. Hotfix branch da main
2. Fix applicato
3. CI passa (OBBLIGATORIO anche in emergency)
4. Deploy diretto su production
5. Merge su main e develop
6. Postmortem entro 24h
```

### Database Migration

```
1. Migration script con ROLLBACK notes
2. Test su staging
3. Backup production
4. Deploy in maintenance window
5. Verify constraints
6. Monitor per 1 ora
```


---

## D.12 AUDIT REQUIREMENTS

### Cosa DEVE essere auditato

| Evento | Tabella | Retention |
|--------|---------|-----------|
| Login/logout | audit_log | 36 mesi |
| Creazione ordine | audit_log + orders | 36 mesi |
| Cambio stato ordine | order_status_history | 36 mesi |
| Transazione billing | billing_ledger | 36 mesi |
| Cambio settings | audit_log | 36 mesi |
| Accesso admin | audit_log | 36 mesi |

### Audit Log Format

```json
{
  "id": "uuid",
  "restaurant_id": "uuid",
  "entity_type": "order",
  "entity_id": "uuid",
  "action": "create",
  "actor_type": "system",
  "actor_id": null,
  "changes": {
    "order_number": "241224-001",
    "total_cents": 1500
  },
  "correlation_id": "uuid",
  "ip_address": "redacted",
  "created_at": "2025-12-24T10:00:00Z"
}
```

### SOC2 Evidence

| Control | Evidence | Location | Frequency |
|---------|----------|----------|-----------|
| Access Review | Access list | /docs/soc2/access/ | Monthly |
| Change Management | PR history | GitHub | Per change |
| Incident Response | Postmortem | /docs/incidents/ | Per P0/P1 |
| DR Test | Drill report | /docs/dr/ | Quarterly |
| Logging | Sample logs | /docs/soc2/logging/ | Monthly |


---

# ============================================================
# CHECKPOINT PARTE 4
# ============================================================

## Verifica Completezza

| Sezione | Contenuto | Status |
|---------|-----------|--------|
| D.1 DO NOT List | 10 regole + enforcement | DONE |
| D.2 Alerting Contract | SLO/SLI + routing | DONE |
| D.3 Metriche | Lista + query SQL | DONE |
| D.4 Dashboard | 3 panel mockup | DONE |
| D.5 CI/CD Gates | GitHub Actions YAML | DONE |
| D.6 Rate Limit | Config + provider limits | DONE |
| D.7 Circuit Breaker | Config + states | DONE |
| D.8 Security | Secrets + access + PII | DONE |
| D.9 Incident | Classification + response | DONE |
| D.10 Kill-Switch | SQL procedures | DONE |
| D.11 Change Management | Normal + emergency | DONE |
| D.12 Audit | Requirements + SOC2 | DONE |


---

# ============================================================
# FINE PARTE 4/5 - GUARDRAIL
# ============================================================
# Prossima parte: SMP-PARTE-5-CHECKLIST.md
# ============================================================

---

## ✅ Patch Checklist (Stack Remap — Railway + Netlify + Stripe + Sentry)

- [ ] **(1) NO TAGLI FUNZIONALI:** testo e codice pre-esistenti sono stati mantenuti integralmente (nessuna rimozione di blocchi “funzionanti”, incluse sezioni per investitori).
- [ ] **(2) RIMOZIONE RIFERIMENTI LEGACY:** rimossi i riferimenti espliciti al vecchio stack (Auth/Edge/DB/BaaS legacy), sostituiti con nuovo stack o wording neutro.
- [ ] **(3) RIADATTAMENTO NUOVO STACK:** dove presenti direttive o snippet legati al vecchio stack, sono stati rimappati su:
  - **Railway** (API + runtime server + Postgres)
  - **Netlify** (hosting frontend / deploy)
  - **Stripe** (pagamenti)
  - **Sentry** (osservabilità — marginale)

**Nota:** hash e diff (orig vs patched) sono forniti nel report di certificazione associato a questo file.
